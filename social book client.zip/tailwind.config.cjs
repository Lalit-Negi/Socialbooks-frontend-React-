/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],  
  theme: {
    extend: {
      colors : {
        main : "rgb(0 195 6 / 72%)",
        hover: "rgb(0 195 6 / 92%)",
      },
       screens : {
        xs : "560px"
       }
    },
  },
  plugins: [],
}
