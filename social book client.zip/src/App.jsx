import React, { useEffect, useRef } from "react";
import SignInForm from "./pages/signin/signinform";
import SignUp from "./pages/signup/signup";
import { Routes, Route, useNavigate } from "react-router-dom";
import useRefresh from "./hooks/useRefresh";
import Home from "./pages/home/home";
import { useSelector, useDispatch } from "react-redux";
import Profile from "./pages/profile/profile";
import Explore from "./pages/explore/explore";
import Chat from "./pages/chat/chat";
import SocketClient from "./socket/socket";
import { SET_SOCKET } from "./store/reducers/socket-reducer";
import Notify from "./components/notify/notify";
import Loader from "./components/loader";
import io from "socket.io-client";
import Notifications from "./pages/notifications/notifications";
import ShowPost from "./pages/post/showPost";

const App = () => {
	const loading = useRefresh();
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const user = useSelector((state) => state.auth.user);

	const PrivateRoute = ({ children }) => {
		const user = useSelector((state) => state.auth.user);
		return user ? children : navigate("/");
	};

	useEffect(() => {
		if (!user) navigate("/");
	}, [user]);

	useEffect(() => {
		const socket = io.connect("http://localhost:5000");
		dispatch(SET_SOCKET({ socket }));
		return () => socket.close();
	}, []);

	return loading ? (
		<Loader />
	) : (
		<div className="App">
			<Notify />
			{user && <SocketClient />}
			<Routes>
				<Route path="/" element={<SignInForm />} />
				<Route path="/signup" element={<SignUp />} />
				<Route
					path="/home"
					element={
						<PrivateRoute>
							<Home />
						</PrivateRoute>
					}
				/>
				<Route
					path="/explore"
					element={
						<PrivateRoute>
							<Explore />
						</PrivateRoute>
					}
				/>
				<Route
					path="profile/:userId"
					element={
						<PrivateRoute>
							<Profile />
						</PrivateRoute>
					}
				/>
				<Route
					path="/chat"
					element={
						<PrivateRoute>
							<Chat />
						</PrivateRoute>
					}
				/>
				<Route
					path="/notification"
					element={
						<PrivateRoute>
							<Notifications />
						</PrivateRoute>
					}
				/>
				<Route
					path="/chat/:userId"
					element={
						<PrivateRoute>
							<Chat />
						</PrivateRoute>
					}
				/>
				<Route
					path="/post/:postId"
					element={
						<PrivateRoute>
							<ShowPost />
						</PrivateRoute>
					}
				/>
			</Routes>
		</div>
	);
};

export default App;
