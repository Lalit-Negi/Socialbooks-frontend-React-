import { useEffect, useState } from "react";
import { refresh } from "../http/api";
import { SET_USER } from "../store/reducers/auth-reducer";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

const useRefresh = () => {
	const [loading, setLoading] = useState(true);
	const dispatch = useDispatch();
	const navigate = useNavigate();

	useEffect(() => {
		const refreshing = async () => {
			try {
				const { data } = await refresh();
				if (data.refresh) {
					dispatch(SET_USER({ user: data.user }));
					setLoading(false);
					navigate("/home");
				} else {
					setLoading(false);
				}
			} catch (error) {
				setLoading(false);
				console.log(error);
				return;
			}
		};
		refreshing();
	}, []);

	return loading;
};

export default useRefresh;
