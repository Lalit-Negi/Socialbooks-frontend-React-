import React from "react";
import { useNavigate } from "react-router-dom";

const Suggestions = ({ profile, _id, name }) => {
	const navigate = useNavigate();
	return (
		<div className="flex flex-col space-y-2 items-center border border-slate-200 py-2 rounded-md">
			<div className="w-12 h-12 md:w-16 md:h-16 overflow-hidden bg-green-500 rounded-full p-[1px]">
				<img
					src={profile}
					alt=""
					className="w-full h-full rounded-full object-cover"
				/>
			</div>
			<p className="text-slate-900 text-sm">{name}</p>
			<button
				className="py-1 px-3 text-xs text-slate-700 bg-slate-200 rounded-md hover:scale-[105%] transition-all duration-300"
				onClick={() => navigate(`/profile/${_id}`)}>
				view profile
			</button>
		</div>
	);
};

export default Suggestions;
