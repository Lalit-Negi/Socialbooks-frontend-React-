import React from "react";

const PostLoader = () => {
	return (
		<div className="w-full flex space-x-4 justify-center py-4">
			<div className="h-2 w-2 rounded-full bg-gray-800 animate-ping"></div>
			<div className="h-2 w-2 rounded-full bg-gray-800 animate-ping"></div>
			<div className="h-2 w-2 rounded-full bg-gray-800 animate-ping"></div>
			<div className="h-2 w-2 rounded-full bg-gray-800 animate-ping"></div>
		</div>
	);
};

export default PostLoader;
