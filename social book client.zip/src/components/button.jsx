import React from 'react'

const Button = ({text , icon , display , clickHandler }) => {
  return (
    <button onClick={clickHandler} className={`text-white bg-main hover:bg-hover transition-all duration-300 rounded-md ${display} py-2 px-4`}> {text}{icon || null} </button>
  )
}

export default Button
