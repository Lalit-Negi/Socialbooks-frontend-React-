import React from "react";
import "./loader.css";
import { useDispatch, useSelector } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";

const NotifyManager = ({ message }) => {
	const dispatch = useDispatch();
	setTimeout(() => {
		dispatch(SET_NOTIFY({ notifyType: {} }));
	}, 1500);
	return (
		<div className="fixed notify v-animation z-50">
			<p className="text-[13px] bg-green-400 text-black tracking-wide py-1 px-2 xs:px-4 rounded-lg">
				{message}
			</p>
		</div>
	);
};
const Notify = () => {
	const notifyType = useSelector((state) => state.notify.notifyType);

	return notifyType.loading ? (
		<div className="loader">
			<div className="cubes">
				<div className="sk-cube sk-cube1"></div>
				<div className="sk-cube sk-cube2"></div>
				<div className="sk-cube sk-cube3"></div>
				<div className="sk-cube sk-cube4"></div>
				<div className="sk-cube sk-cube5"></div>
				<div className="sk-cube sk-cube6"></div>
				<div className="sk-cube sk-cube7"></div>
				<div className="sk-cube sk-cube8"></div>
				<div className="sk-cube sk-cube9"></div>
			</div>
		</div>
	) : notifyType.success ? (
		<NotifyManager message={notifyType.success} />
	) : notifyType.error ? (
		<NotifyManager message={notifyType.error} />
	) : (
		""
	);
};

export default Notify;
