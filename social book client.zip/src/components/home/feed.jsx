import React, { useState } from "react";
import Status from "./status/status";
import PostModel from "../../pages/post/post-model";
import { posts } from "../../constants";

const Feed = () => {
	const [openPost, setOpenPost] = useState(false);

	return (
		<div className="relative">
			<div className="flex space-x-4 overflow-x-scroll status pb-4 mb-4">
				{posts.map((status, key) => {
					return <Status status={status} key={key} />;
				})}
			</div>

			<div className="flex my-8 items-center">
				<div className="mr-4 flex-1 border-b border-slate-200 pl-2">
					<input
						type="text"
						placeholder="write something here ..."
						className="focus:outline-none py-1 text-xs xs:text-sm w-full bg-transparent"
					/>
				</div>
				<button
					className="bg-main rounded-md py-2 px-2 text-xs xs:text-sm xs:px-3 text-white capitalize hover:bg-hover transition-all duration-300"
					onClick={() => setOpenPost((prev) => !prev)}>
					create post
				</button>
				<PostModel openPost={openPost} setOpenPost={setOpenPost} />
			</div>
		</div>
	);
};

export default Feed;
