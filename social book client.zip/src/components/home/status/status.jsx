import { useState } from "react";
import Model from "./model";

const Status = ({ status }) => {
	const [showModel, setShowModel] = useState(false);

	return (
		<div>
			<div onClick={() => setShowModel((prev) => !prev)}>
				<div className="h-20 w-20 rounded-full overflow-hidden p-[3px] bg-gradient-to-bl to-pink-400 via-white from-green-600 grid place-items-center">
					<div className="rounded-full overflow-hidden border-[4px] border-white w-full h-full">
						<img
							src={status.src}
							alt="story"
							className="w-full h-full object-cover"
						/>
					</div>
				</div>
				<p className="text-[12px] font-extralight mt-1 truncate text-center">
				 	Lalit Negi
				</p>
			</div>
			<Model
				userStatus={status.src}
				userProfile={status.src}
				userName={"Lalit Negi"}
				showModel={showModel}
				setShowModel={setShowModel}
			/>
		</div>
	);
};

export default Status;
