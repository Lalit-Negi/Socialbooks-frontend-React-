import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper";

import "swiper/css/pagination";
import "swiper/css"

const Model = ({
	userStatus,
	userProfile,
	userName,
	showModel,
	setShowModel,
}) => {
	return (
		<div className={showModel ? "status-model z-50" : "hidden"}>
			<div
				className="absolute top-2 right-2 bg-slate-100 rounded-full"
				onClick={() => setShowModel((prev) => !prev)}>
				<svg
					fill="black"
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="35"
					height="35">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
				</svg>
			</div>

			<div className="bg-black flex justify-center overflow-hidden rounded-md mt-4 relative w-[280px] xs:w-[400px] min-h-[400px] max-h-[450px]">
				<div className="flex items-center absolute top-2 left-2 p-2 z-50">
					<div className="w-10 h-10 rounded-full mr-2 overflow-hidden">
						<img
							src={userProfile}
							alt=""
							className="w-full h-full object-cover"
						/>
					</div>
					<p className="text-xs tracking-wide capitalize text-gray-100">
						{userName}
					</p>
				</div>
				<Swiper>
					{Array(4)
						.fill(0)
						.map((ele, key) => {
							return (
								<SwiperSlide
									key={key}
									spaceBetween={0}
									slidesPerView={1}
									modules={[Pagination]}
									pagination={{
										dynamicBullets: true,
									}}
									className="swiper">
									<img
										src={userStatus}
										alt=""
										className="w-full h-full object-contain"
									/>
								</SwiperSlide>
							);
						})}
				</Swiper>
			</div>
		</div>
	);
};

export default Model;
