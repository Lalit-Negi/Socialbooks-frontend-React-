import React, { useEffect, useState } from "react";
import Comment from "./comment";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper";
import "swiper/css/pagination";
import "swiper/css";
import Likes from "./likes";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { useNavigate } from "react-router-dom";
import { REMOVE_POSTS } from "../../../store/reducers/profile-reducer";
import { createNotification } from "../../../http/api";

const Post = ({
	post,
	handleLike,
	handleDislike,
	handleComment,
	handleDeletePost,
}) => {
	const auth = useSelector((state) => state.auth);
	const [like, setLike] = useState();
	const [comment, setComment] = useState("");
	const [openComments, setOpenComments] = useState(false);
	const [openLikes, setOpenLikes] = useState(false);
	const [removePost, setRemovePost] = useState(false);
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const socket = useSelector((state) => state.socketConnection.socket);

	useEffect(() => {
		post.likes.forEach((like) => {
			if (like._id === auth.user._id) {
				setLike(true);
			}
		});
	}, []);

	const handleLikeOnPost = async (postId) => {
		setLike(true);
		handleLike(postId);

		const data = {
			text: `${auth.user.name} liked your post`,
			link: `/post/${postId}`,
			profile: auth.user.profile,
			recipient: [post.user._id],
		};

		try {
			const res = await createNotification(data);
			if (res.status === 201) {
				socket.emit("LIKE_NOTIFICATION", res.data.notification);
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleDislikeOnPost = (postId) => {
		setLike(false);
		handleDislike(postId);
	};

	const handleCommentOnPost = async (postId) => {
		handleComment(postId, comment.trim(), setComment);

		const data = {
			text: `${auth.user.name} commented on your post. "${comment}"`,
			link: `/post/${postId}`,
			profile: auth.user.profile,
			recipient: [post.user._id],
		};

		try {
			const res = await createNotification(data);
			if (res.status === 201) {
				socket.emit("LIKE_NOTIFICATION", res.data.notification);
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	return (
		<div className="mb-10 border border-slate-200 rounded-md v-animation py-4 px-2 relative">
			<div className="flex space-x-2 items-center justify-between">
				<div
					className="flex space-x-3 items-center cursor-pointer"
					onClick={() => {
						dispatch(REMOVE_POSTS());
						navigate(`/profile/${post.user._id}`);
					}}>
					<div className="overflow-hidden h-9 w-9 rounded-full">
						<img
							src={post.user.profile || ""}
							alt=""
							className="w-full h-full object-cover"
						/>
					</div>
					<p className="text-lg font-medium text-slate-800 capitalize">
						{post.user.name}
					</p>
				</div>
				{auth.user._id === post.user._id ? (
					<div>
						<svg
						className="w-10 h-10 bg-slate-200 rounded-full p-2"
							onClick={() => setRemovePost((prev) => !prev)}
							fill="gray"
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 24 24"
							width="27"
							height="27">
							<path fill="none" d="M0 0h24v24H0z" />
							<path d="M17 6h5v2h-2v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8H2V6h5V3a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v3zm1 2H6v12h12V8zm-9 3h2v6H9v-6zm4 0h2v6h-2v-6zM9 4v2h6V4H9z" />
						</svg>

						<div
							className={
								removePost
									? "p-4 bg-white border border-slate-100 rounded-md shadow-lg v-animation absolute z-30 right-2 left-2 top-[18%] grid place-items-center mx-auto max-w-[280px]"
									: "hidden"
							}>
							<p className="text-slate-700 text-lg mb-4">Delete post</p>
							<div className="flex justify-center items-center space-x-3 xs:space-x-6 text-white">
								<button
									className="capitalize bg-main hover:bg-hover px-2 xs:px-4 rounded-md py-1"
									onClick={() => setRemovePost((prev) => !prev)}>
									cancel
								</button>
								<button
									className="capitalize bg-main hover:bg-hover px-2 xs:px-4 rounded-md py-1"
									onClick={() => handleDeletePost(post._id, setRemovePost)}>
									delete
								</button>
							</div>
						</div>
					</div>
				) : (
					""
				)}
			</div>

			<div className="inline-block bg-slate-200 py-1 px-2 rounded-full mt-2">
				<div className="flex space-x-2 items-center">
					<svg
						fill="gray"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="17"
						height="17">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M6.235 6.453a8 8 0 0 0 8.817 12.944c.115-.75-.137-1.47-.24-1.722-.23-.56-.988-1.517-2.253-2.844-.338-.355-.316-.628-.195-1.437l.013-.091c.082-.554.22-.882 2.085-1.178.948-.15 1.197.228 1.542.753l.116.172c.328.48.571.59.938.756.165.075.37.17.645.325.652.373.652.794.652 1.716v.105c0 .391-.038.735-.098 1.034a8.002 8.002 0 0 0-3.105-12.341c-.553.373-1.312.902-1.577 1.265-.135.185-.327 1.132-.95 1.21-.162.02-.381.006-.613-.009-.622-.04-1.472-.095-1.744.644-.173.468-.203 1.74.356 2.4.09.105.107.3.046.519-.08.287-.241.462-.292.498-.096-.056-.288-.279-.419-.43-.313-.365-.705-.82-1.211-.96-.184-.051-.386-.093-.583-.135-.549-.115-1.17-.246-1.315-.554-.106-.226-.105-.537-.105-.865 0-.417 0-.888-.204-1.345a1.276 1.276 0 0 0-.306-.43zM12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z" />
					</svg>
					<p className="text-slate-700 text-[10px]">
						{moment(post.createdAt).fromNow("LTS")} <span>ago</span>
					</p>
				</div>
			</div>

			<p className="text-[14px] my-2 tracking-wide rounded-xl text-slate-600">
				{post.caption}
			</p>

			<Swiper
				spaceBetween={0}
				slidesPerView={1}
				modules={[Pagination]}
				pagination={{
					dynamicBullets: true,
				}}
				className="swiper pb-4">
				{post.images.map((image, key) => {
					return (
						<SwiperSlide key={key}>
							<div className="overflow-hidden mb-4 rounded-sm bg-slate-100 h-[260px]">
								<img
									src={image}
									alt="post"
									className="h-full w-full object-contain"
								/>
							</div>
						</SwiperSlide>
					);
				})}
			</Swiper>

			<div className="flex justify-end text-gray-600 text-xs mb-2">
				<div className="">
					<button className="after:contents-[''] after:inline-block after:mx-1 after:w-1 after:h-1 after:mb-[2px] after:bg-gray-500 after:rounded-full">
						{post.comments.length} comments
					</button>
					<button onClick={() => setOpenLikes((prev) => !prev)}>
						{post.likes.length} likes
					</button>
					<Likes
						likes={post.likes}
						openLikes={openLikes}
						setOpenLikes={setOpenLikes}
					/>
				</div>
			</div>

			<hr className="mb-2" />

			<div className="flex space-x-6 items-center">
				<button className="flex items-center space-x-2 text-gray-600">
					{like ? (
						<svg
							onClick={() => {
								handleDislikeOnPost(post._id);
							}}
							fill="red"
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 24 24"
							width="24"
							height="24">
							<path fill="none" d="M0 0H24V24H0z" />
							<path d="M16.5 3C19.538 3 22 5.5 22 9c0 7-7.5 11-10 12.5C9.5 20 2 16 2 9c0-3.5 2.5-6 5.5-6C9.36 3 11 4 12 5c1-1 2.64-2 4.5-2z" />
						</svg>
					) : (
						<svg
							onClick={() => {
								handleLikeOnPost(post._id);
							}}
							fill="gray"
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 24 24"
							width="24"
							height="24">
							<path fill="none" d="M0 0H24V24H0z" />
							<path d="M12.001 4.529c2.349-2.109 5.979-2.039 8.242.228 2.262 2.268 2.34 5.88.236 8.236l-8.48 8.492-8.478-8.492c-2.104-2.356-2.025-5.974.236-8.236 2.265-2.264 5.888-2.34 8.244-.228zm6.826 1.641c-1.5-1.502-3.92-1.563-5.49-.153l-1.335 1.198-1.336-1.197c-1.575-1.412-3.99-1.35-5.494.154-1.49 1.49-1.565 3.875-.192 5.451L12 18.654l7.02-7.03c1.374-1.577 1.299-3.959-.193-5.454z" />
						</svg>
					)}
					<span className="text-[14px]">Like</span>
				</button>
				<button
					className="flex items-center space-x-2 text-gray-600"
					onClick={() => setOpenComments((prev) => !prev)}>
					<svg
						fill="gray"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="24"
						height="24">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M7.291 20.824L2 22l1.176-5.291A9.956 9.956 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10a9.956 9.956 0 0 1-4.709-1.176zm.29-2.113l.653.35A7.955 7.955 0 0 0 12 20a8 8 0 1 0-8-8c0 1.334.325 2.618.94 3.766l.349.653-.655 2.947 2.947-.655z" />
					</svg>
					<span className="text-[14px]">Comments</span>
				</button>
			</div>

			<div className="border-b-[1px] border-slate-200 my-4 flex justify-between items-center">
				<textarea
					value={comment}
					onChange={(e) => setComment((prev) => e.target.value)}
					type="text"
					rows={1}
					placeholder="write a comment ..."
					className="py-2 px-4 focus:outline-none text-sm text-black bg-transparent w-full mr-2 md:mr-12"
				/>
				<button className="text-xs mr-4">
					<svg
						onClick={() => handleCommentOnPost(post._id)}
						fill="gray"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="24"
						height="24">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M3.741 1.408l18.462 10.154a.5.5 0 0 1 0 .876L3.741 22.592A.5.5 0 0 1 3 22.154V1.846a.5.5 0 0 1 .741-.438zM5 13v6.617L18.85 12 5 4.383V11h5v2H5z" />
					</svg>
				</button>
			</div>

			<div
				className={
					openComments
						? "h-[12rem] overflow-y-scroll v-animation transition-all duration-800"
						: "hidden"
				}>
				{post.comments.length > 0 ? (
					post.comments.map((comment, key) => {
						return <Comment key={key} comment={comment} />;
					})
				) : (
					<p className="text-center text-sm capitalize text-slate-500">
						no comments
					</p>
				)}
			</div>
		</div>
	);
};

export default Post;
