import React from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { REMOVE_POSTS, SET_POSTS, SET_SKIP } from "../../../store/reducers/profile-reducer"

const Likes = ({ likes, openLikes, setOpenLikes }) => {
	const navigate = useNavigate()
	const dispatch = useDispatch()
	return (
		<div
			className={
				openLikes
					? "fixed md:absolute top-10 left-2 right-2 z-50 bottom-0 grid place-items-center"
					: "hidden"
			}>
			<div className="w-full h-full p-4 overflow-y-scroll bg-slate-100 rounded-lg shadow-xl border border-slate-200">
				<button
					onClick={() => setOpenLikes((prev) => !prev)}
					className="absolute top-2 right-2 bg-slate-200 rounded-full">
					<svg
						fill="black"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="40"
						height="40">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
					</svg>
				</button>
				{likes.length > 0 ? (
					<div className="pt-10">
						{likes?.map((like, key) => {
							return (
								<div
									onClick={() =>{ 										
										dispatch(REMOVE_POSTS())
										navigate(`/profile/${like._id}`)}}
									className="flex space-x-3 bg-white items-center mb-3 rounded-lg px-3 xs:px-6 py-3 hover:glass ease-linear transition-all duration-300 w-full"
									key={key}>
									<div className="rounded-full overflow-hidden w-10 h-10">
										<img
											src={like.profile}
											alt=""
											className="h-full w-full object-cover"
										/>
									</div>
									<p className="text-sm">{like.name}</p>
								</div>
							);
						})}
					</div>
				) : (
					<p className="text-center text-lg capitalize">no likes</p>
				)}
			</div>
		</div>
	);
};

export default Likes;
