import moment from "moment";
import React, { useState } from "react";

const Comment = ({ comment }) => {
	const [seeMore, setSeeMore] = useState(false);
	return (
		<div className="comments relative">
			<div className="flex space-x-3 hover:bg-slate-100 transition-all duration-300 ease-linear py-3 rounded-lg px-2 sm:px-4 border border-slate-50">
				<div className="overflow-hidden w-9 h-9 rounded-full">
					<img
						src={comment.userComment.profile}
						alt=""
						className="w-full h-full object-cover"
					/>
				</div>
				<div className="flex-1 overflow-hidden">
					<p className=" text-[14px] font-medium text-black mb-[1px]">
						{comment.userComment.name}
					</p>
					<p className="text-[13px] text-gray-600">
						{comment.text.length < 100 ? (
							comment.text
						) : !seeMore ? (
							<p>
								<p>
									{comment.text.slice(0, 100) + " ..."}
									<p
										className="text-xs underline text-slate-500"
										onClick={() => setSeeMore((prev) => !prev)}>
										see more{" "}
									</p>
								</p>
							</p>
						) : (
							comment.text
						)}
					</p>
				</div>
				<span className="absolute top-2 right-3 bg-slate-200 rounded-md py-1 px-2  sm:px-4 text-xs xs:text-sm">
					<p className="text-[9px] text-slate-900">
						{moment(comment.createdAt).fromNow("hh:mm:ss", "a")}
					</p>
				</span>
			</div>
		</div>
	);
};

export default Comment;
