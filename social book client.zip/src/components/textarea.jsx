import React from 'react'

const TextArea = ({name , rows , placeHolder , value , handleChange}) => {
  return (
    <div>
      <textarea name={name} rows={rows} value={value} onChange={handleChange} placeholder={placeHolder}  className="w-full px-4 py-3 bg-slate-100 rounded-md focus:outline-none" ></textarea>
    </div>
  )
}

export default TextArea
