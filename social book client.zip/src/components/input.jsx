import React from 'react'

const Input = ({type , placeHolder , name , handleChange , value}) => {
  return (
    <div className='max-w-[400px] my-4'>
      <input autoComplete='false' autoCorrect='false' autoCapitalize='false' type={type} name={name} placeholder={placeHolder} value={value} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-md focus:outline-none"/>
    </div>
  )
}

export default Input
