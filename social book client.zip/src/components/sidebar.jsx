import { menuItems } from "../constants";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { signOut } from "../http/api";
import React from "react";
import { SET_NOTIFY } from "../store/reducers/notify-reducer";
import { SET_USER } from "../store/reducers/auth-reducer";
import { REMOVE_POSTS } from "../store/reducers/profile-reducer";
import { SET_IS_NOTIFICATION } from "../store/reducers/notification-reducer";
import { SET_MESSAGE_COUNT } from "../store/reducers/conversation-reducer";
import  {SET_SOCKET} from "../store/reducers/socket-reducer"
import { REMOVE_POSTS as REMOVE_HOME_POSTS} from "../store/reducers/homePost-reducer"
import { REMOVE_ALL} from "../store/reducers/conversation-reducer"

const Sidebar = () => {
	const navigate = useNavigate();
	const { profile, _id: userId } = useSelector((state) => state.auth.user);
	const dispatch = useDispatch();
	const isNotification = useSelector(
		(state) => state.notification.isNotification
	);
	const messageCount = useSelector((state) => state.conversation.messageCount);

	const handleSignOut = async () => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await signOut();
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			if (res.status === 200) {
				dispatch(SET_USER({ user: null }));
				dispatch(SET_SOCKET({ socket : null}))
				dispatch(REMOVE_HOME_POSTS());
				dispatch(REMOVE_POSTS())
				dispatch(REMOVE_ALL());
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: res.data.message } }));
		}
	};

	return (
		<div className="md:px-2 border-r border-slate-200 shadow-2xl">
			<h1
				className="hidden md:block md:text-[2.8rem] font-extrabold brand h-[20vh] pt-7 md:pl-4 cursor-pointer text-transparent bg-clip-text bg-gradient-to-l to-green-600 via-pink-600 from-blue-600"
				onClick={() => navigate("/home")}>
				let's talk
			</h1>

			<div className="md:h-[80vh] md:static md:bg-none flex fixed bottom-0 border border-slate-200 md:border-none md:rounded-none mx-auto right-0 left-0 z-[999] bg-white md:flex-col justify-around p-2 md:pb-6">
				{menuItems.map((item, key) => (
					<div
						onClick={
							item.text === "signout"
								? () => {
										confirm("Do you to sign out?") && handleSignOut();
										dispatch(SET_MESSAGE_COUNT({ messageCount: 0 }));
								  }
								: item.text === "profile"
								? () => {
										dispatch(REMOVE_POSTS());
										dispatch(SET_MESSAGE_COUNT({ messageCount: 0 }));
										navigate(`/profile/${userId}`);
								  }
								: item.text === "notification"
								? () => {
										dispatch(SET_IS_NOTIFICATION({ isNotification: false }));
										dispatch(SET_MESSAGE_COUNT({ messageCount: 0 }));
										navigate(item.link);
								  }
								: () => {
										dispatch(SET_MESSAGE_COUNT({ messageCount: 0 }));
										navigate(item.link);
								  }
						}
						className="relative flex md:p-4 items-center hover:bg-slate-100 hover:text-black rounded-xl transition-all duration-300 cursor-pointer ease-in-out"
						key={key}>
						{item.icon || (
							<div className="w-[27px] h-[27px] overflow-hidden rounded-full">
								<img
									src={profile}
									alt="user"
									className="object-cover h-full w-full"
								/>
							</div>
						)}

						<h4 className="capitalize ml-4 text-lg tracking-wide text-gray-600 relative hidden md:block">
							{item.text}
							{item.text === "notification" ? (
								isNotification ? (
									<span className="w-2 h-2 bg-red-600 absolute top-0 -right-4 rounded-full"></span>
								) : (
									""
								)
							) : (
								""
							)}
							{item.text === "message" ? (
								messageCount !== 0 ? (
									location.pathname !== "/chat" ? (
										<span className="w-5 h-5 flex justify-center items-center text-white text-[11px] bg-red-600 absolute top-0 -right-6 rounded-full">
											{messageCount}
										</span>
									) : (
										""
									)
								) : (
									""
								)
							) : (
								""
							)}
						</h4>
					</div>
				))}
			</div>
		</div>
	);
};

export default Sidebar;
