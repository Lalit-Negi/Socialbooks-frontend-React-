import React from "react";
import { useNavigate } from "react-router-dom";

const Account = ({to , text1 , text2}) => {

	const navigate = useNavigate();

	return (
		<div className="py-6">
			<p className="text-sm text-center cursor-pointer">
				{text1} {" "}
				<span className="text-blue-600 underline" onClick={() => navigate(to)}>
					{text2}
				</span>
			</p>
		</div>
	);
};

export default Account;
