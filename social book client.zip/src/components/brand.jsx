import React from "react";

const Brand = () => {
	return (
		<div>
			<h1 className="text-[3.4rem] brand text-center font-extrabold mb-4">let's talk</h1>
		</div>
	);
};

export default Brand;
