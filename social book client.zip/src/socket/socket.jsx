import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
	SET_LIKE,
	SET_DISLIKE,
	SET_COMMENT,
	ADD_POST,
	SET_DELETE,
} from "../store/reducers/homePost-reducer";
import { ADD_FOLLOWER, REMOVE_FOLLOWER } from "../store/reducers/auth-reducer";
import {
	ADD_NOTIFICATION,
	SET_IS_NOTIFICATION,
} from "../store/reducers/notification-reducer";
import {
	ADD_MESSAGE,
	ADD_USER,
	SET_ACTIVE,
	SET_LASTSEEN,
	SET_LAST_MESSAGE,
	SET_USER_MESSAGE_COUNT,
} from "../store/reducers/conversation-reducer";
import moment from "moment"

const SocketClient = () => {
	const auth = useSelector((state) => state.auth);
	const dispatch = useDispatch();
	const socket = useSelector((state) => state.socketConnection.socket);
	const users = useSelector((state) => state.conversation.users);

	useEffect(() => {
		// join
		socket.emit("JOIN", auth.user._id);

		//like post
		socket.on("LIKE_POST", (data) => {
			dispatch(SET_LIKE({ postId: data.postId, user: data.user }));
		});

		//unlike post
		socket.on("UNLIKE_POST", (data) => {
			dispatch(SET_DISLIKE({ postId: data.postId, userId: data.userId }));
		});

		// comment on post
		socket.on("COMMENT_POST", (data) => {
			dispatch(SET_COMMENT({ postId: data.postId, user: data.user }));
		});

		// add post
		socket.on("ADD_POST", (data) => {
			dispatch(ADD_POST({ post: data.post }));
		});

		// delete post
		socket.on("DELETE_POST", (data) => {
			dispatch(SET_DELETE({ postId: data.postId }));
		});

		// follow
		socket.on("FOLLOW", (data) => {
			dispatch(ADD_FOLLOWER({ user: data.user }));
		});

		// unfollow
		socket.on("UNFOLLOW", (data) => {
			dispatch(REMOVE_FOLLOWER({ userId: data.userId }));
		});

		// notifcation
		socket.on("NOTIFICATION", (data) => {
			dispatch(ADD_NOTIFICATION({ notification: data }));
			dispatch(SET_IS_NOTIFICATION({ isNotification: true }));
		});

		// follow notification
		socket.on("FOLLOW_NOTIFICATION", (data) => {
			dispatch(ADD_NOTIFICATION({ notification: data }));
			dispatch(SET_IS_NOTIFICATION({ isNotification: true }));
		});

		// like notification
		socket.on("LIKE_NOTIFICATION", (data) => {
			dispatch(ADD_NOTIFICATION({ notification: data }));
			dispatch(SET_IS_NOTIFICATION({ isNotification: true }));
		});

		// comment notification
		socket.on("COMMENT_NOTIFICATION", (data) => {
			dispatch(ADD_NOTIFICATION({ notification: data }));
			dispatch(SET_IS_NOTIFICATION({ isNotification: true }));
		});

		// message
		socket.on("MESSAGE", (data) => {
			dispatch(
				ADD_USER({
					user: { count: 0, active: true, lastSeen: "", ...data.user },
				})
			);
			dispatch(
				SET_LAST_MESSAGE({ lastMessage: data.lastMessage, userId: data.sender })
			);
			dispatch(
				ADD_MESSAGE({
					message: {
						message: data.message,
						sender: data.sender,
						media: data.media,
						time: data.time,
					},
					userId: data.sender,
				})
			);
			dispatch(SET_USER_MESSAGE_COUNT({ userId: data.sender }));
			dispatch(SET_ACTIVE({ active: true, userId: data.sender }));
			dispatch(SET_LASTSEEN({ lastSeen: "online", userId: data.sender }));
		});

		socket.on("UNACTIVE", (data) => {
			dispatch(SET_ACTIVE({ active: false, userId: data.userId }));
			dispatch(SET_LASTSEEN({ lastSeen: moment(Date.now()).format("LT") , userId: data.userId }));
		});

		socket.on("TYPING", (data) => {
			dispatch(SET_LASTSEEN({ lastSeen: "tying...", userId: data.userId }));
			setTimeout(() => {
				dispatch(
					SET_LASTSEEN({
						lastSeen: "online",
						userId: data.userId,
					})
				);
			}, 2000);
		});

		return () => {
			socket.off("ADD_POST");
			socket.off("COMMENT_POST");
			socket.off("UNLIKE_POST");
			socket.off("JOIN");
			socket.off("LIKE_POST");
			socket.off("DELETE_POST");
			socket.off("FOLLOW");
			socket.off("UNFOLLOW");
			socket.off("NOTIFICATION");
			socket.off("FOLLOW_NOTIFICATION");
			socket.off("LIKE_NOTIFICATION");
			socket.off("COMMENT_NOTIFICATION");
			socket.off("MESSAGE");
			socket.off("UNACTIVE");
			socket.off("TYPING");
		};
	}, [socket]);
};

export default SocketClient;
