export const menuItems = [
	{
		item: 1,
		icon: (
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 26 26"
				width="27"
				height="27">
				<path fill="none" d="M0 0h26v26H0z" />
				<path d="M19 21H5a1 1 0 0 1-1-1v-9H1l10.327-9.388a1 1 0 0 1 1.346 0L23 11h-3v9a1 1 0 0 1-1 1zm-6-2h5V9.157l-6-5.454-6 5.454V19h5v-6h2v6z" />
			</svg>
		),
		text: "home",
		link: "/home",
	},
	{
		item: 2,
		icon: (
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 26 26"
				width="27"
				height="27">
				<path fill="none" d="M0 0h26v26H0z" />
				<path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm3.5-11.5l-2 5-5 2 2-5 5-2z" />
			</svg>
		),
		text: "explore",
		link: "/explore",
	},
	{
		item: 3,
		icon: (
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 24 24"
				width="24"
				height="24">
				<path fill="none" d="M0 0h24v24H0z" />
				<path d="M7.291 20.824L2 22l1.176-5.291A9.956 9.956 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10a9.956 9.956 0 0 1-4.709-1.176zm.29-2.113l.653.35A7.955 7.955 0 0 0 12 20a8 8 0 1 0-8-8c0 1.334.325 2.618.94 3.766l.349.653-.655 2.947 2.947-.655z" />
			</svg>
		),
		text: "message",
		link: "/chat",
	},
	{
		item: 4,
		icon: (
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 24 24"
				width="27"
				height="27">
				<path fill="none" d="M0 0h24v24H0z" />
				<path d="M5 18h14v-6.969C19 7.148 15.866 4 12 4s-7 3.148-7 7.031V18zm7-16c4.97 0 9 4.043 9 9.031V20H3v-8.969C3 6.043 7.03 2 12 2zM9.5 21h5a2.5 2.5 0 1 1-5 0z" />
			</svg>
		),
		text: "notification",
		link: "/notification",
	},

	{
		item: 5,
		text: "profile",
	},

	{
		item: 6,
		icon: (
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 24 24"
				width="27"
				height="27">
				<path fill="none" d="M0 0h24v24H0z" />
				<path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2a9.985 9.985 0 0 1 8 4h-2.71a8 8 0 1 0 .001 12h2.71A9.985 9.985 0 0 1 12 22zm7-6v-3h-8v-2h8V8l5 4-5 4z" />
			</svg>
		),
		text: "signout",
		link: "/signout",
	},
];

import sea from "./assets/images/user.png";

export const posts = [
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},
	{
		post: 1,
		src: sea,
		caption: "we will ready to do it.",
	},	
];
