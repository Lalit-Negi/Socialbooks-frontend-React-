import axios from "axios";

// axios object initialization

const api = axios.create({
	baseURL : "http://localhost:5000",
	headers: {
		"Content-Type": "application/json",
		Accept: "application/json",
	},
	withCredentials: true,
});

// auth api's
export const signIn = (data) => api.post("/api/signin", data);
export const sendOtp = (data) => api.post("/api/sendotp", data);
export const verifyOtp = (data) => api.post("/api/verifyotp", data);
export const signUp = (data) => api.post("/api/signup", data);
export const updateProfile = (data) => api.put("/api/updateprofile", data);
export const signOut = () => api.get("/api/signout");
export const refresh = () => api.get("/api/refresh");

// posts api's
export const createPost = (data) =>
	axios({
		method: "post",
		url: "http://localhost:5000/api/createpost",
		headers: {
			"Content-Type": "multipart/form-data",
			Accept: "application/json",
		},
		data: data,
		withCredentials: true,
	});
export const userPosts = (data) =>
	api.get(
		`/api/userposts?userId=${data.userId}&&skip=${data.skip}&&limit=${data.limit}`
	);
export const likePost = (data) => api.put("/api/likepost", data);
export const dislikePost = (data) => api.put("/api/dislikePost", data);
export const commentPost = (data) => api.put("/api/commentpost", data);
export const deletePost = (data) =>
	api.delete(`/api/deletepost?postId=${data}`);
export const feed = (data) =>
	api.get(`/api/feed?limit=${data.limit}&&skip=${data.skip}`);
export const explore = (data) =>
	api.get(`/api/explore?limit=${data.limit}&&skip=${data.skip}`);
export const getPost = (data) => api.get(`/api/post/${data.postId}`);

// notification api's
export const createNotification = (data) =>
	api.post("/api/createnotification", data);

// user related api's
export const searchUser = (data) => api.post("/api/searchuser", data);
export const userProfile = (data) => api.get(`/api/userprofile/${data}`);
export const follow = (data) => api.put("/api/follow", data);
export const unFollow = (data) => api.put("/api/unfollow", data);

// suggestions
export const suggestions = (data) => api.post("/api/suggestions" , data)

// contacts
export const contacts = () => api.get("/api/contacts");

// chat api's
export const getMessages = (data) => api.get(`/api/messages/${data.userId}`);
export const transferMessage = (data) => api.patch("/api/message", data);
export const deleteAllMessages = (data) => api.delete(`/api/deleteallmessages/${data.userId}`)

export default api;

// interceptors

api.interceptors.response.use(
	(res) => res,
	async (error) => {
		const originalRequest = error.config;
		if (error.response.status === 401 && !originalRequest._retry) {
			originalRequest._retry = true;
			try {
				await axios.get("http://localhost:5000/api/refresh", {
					withCredentials: true,
				});
				return await api.request(originalRequest);
			} catch (err) {
				console.log(err.message);
			}
		}
		throw error;
	}
);

axios.interceptors.response.use(
	(res) => res,
	async (error) => {
		const originalRequest = error.config;
		if (error.response.status === 401 && !originalRequest._retry) {
			originalRequest._retry = true;
			try {
				await axios.get("http://localhost:5000/api/refresh", {
					withCredentials: true,
				});
				return await axios.request(originalRequest);
			} catch (err) {
				console.log(err.message);
			}
		}
		throw error;
	}
);
