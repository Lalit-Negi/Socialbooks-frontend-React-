import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	loading: true,
	users: [],
};

const suggestions = createSlice({
	name: "suggestions",
	initialState,
	reducers: {
		SET_USERS: (state, action) => {
			state.users = action.payload.users;
		},
		SET_LOADING: (state, action) => {
			state.loading = action.payload.loading;
		},
	},
});

export const { SET_USERS, SET_LOADING } = suggestions.actions;
export default suggestions.reducer;
