import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	notifyType: {},
};

const notify = createSlice({
	name: "notify",
	initialState,
	reducers: {
		SET_NOTIFY: (state, action) => {
			state.notifyType = action.payload.notifyType;
		},
	},
});

export const { SET_NOTIFY } = notify.actions;
export default notify.reducer;
