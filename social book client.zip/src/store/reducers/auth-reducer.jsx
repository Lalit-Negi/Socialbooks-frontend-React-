import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	signUp: {
		name: "",
		password: "",
		confirmPassword: "",
		bio: "",
		phone: "",
		hash: "",
		otp: "",
	},
	user: null,
};

const auth = createSlice({
	name: "auth",
	initialState,
	reducers: {
		SET_USER: (state, action) => {
			state.user = action.payload.user;
		},
		SET_HASH: (state, action) => {
			state.signUp.hash = action.payload.hash;
		},
		SET_OTP: (state, action) => {
			state.signUp.otp = action.payload.otp;
		},
		SET_PHONE: (state, action) => {
			state.signUp.phone = action.payload.phone;
		},
		SET_SIGNUP_DATA: (state, action) => {
			state.signUp.name = action.payload.name;
			state.signUp.password = action.payload.password;
			state.signUp.confirmPassword = action.payload.confirmPassword;
			state.signUp.bio = action.payload.bio;
		},
		SET_FOLLOWING: (state, action) => {
			state.user.following.push(action.payload.user);
		},
		SET_UNFOLLOWING: (state, action) => {
			state.user.following = state.user.following.filter(
				(user) => user._id !== action.payload.userId
			);
		},
		ADD_FOLLOWER: (state, action) => {
			const index = state.user.followers.findIndex(
				(follower) => follower._id === action.payload.user._id
			);
			index === -1 && state.user.followers.push(action.payload.user);
		},
		REMOVE_FOLLOWER: (state, action) => {
			state.user.followers = state.user.followers.filter(
				(user) => user._id !== action.payload.userId
			);
		},
	},

});

export const {
	SET_OTP,
	SET_USER,
	SET_HASH,
	SET_PHONE,
	SET_SIGNUP_DATA,
	SET_FOLLOWING,
	SET_UNFOLLOWING,
	ADD_FOLLOWER,
	REMOVE_FOLLOWER,
} = auth.actions;
export default auth.reducer;


