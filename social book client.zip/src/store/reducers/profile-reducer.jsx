import { createSlice } from "@reduxjs/toolkit";
const initialState = {
	loading: false,
	posts: [],
	user: null,
	skip: 0,
	limit: 3,
};

const profile = createSlice({
	name: "profile",
	initialState,
	reducers: {
		SET_SKIP: (state, action) => {
			state.skip = action.payload.skip;
		},
		SET_USER: (state, action) => {
			state.user = action.payload.user;
		},
		SET_POSTS: (state, action) => {
			state.posts = action.payload.posts;
			state.skip = state.skip + 3;
		},
		SET_LOADING: (state, action) => {
			state.loading = action.payload.loading;
		},
		SET_LIKE: (state, action) => {
			state.posts.map((post) => {
				if (post._id === action.payload.postId) {
					post.likes.push(action.payload.user);
				}
			});
		},
		SET_DISLIKE: (state, action) => {
			state.posts.map((post) => {
				if (post._id === action.payload.postId) {
					const index = post.likes.findIndex(
						(like) => like._id === action.payload.userId
					);
					post.likes.splice(index, 1);
				}
			});
		},
		SET_COMMENT: (state, action) => {
			state.posts.map((post) => {
				if (post._id === action.payload.postId) {
					post.comments.unshift(action.payload.user);
				}
			});
		},
		SET_DELETE: (state, action) => {
			state.posts = state.posts.filter(
				(post) => post._id !== action.payload.postId
			);
		},
		SET_FOLLOW: (state, action) => {
			state.user.followers.push(action.payload.user);
		},
		SET_UNFOLLOW: (state, action) => {
			state.user.followers = state.user.followers.filter(
				(user) => user._id !== action.payload.userId
			);
		},
		REMOVE_POSTS: (state, action) => {
			state.posts = [];
			state.skip = 0;
		},
	},
});

export const {
	REMOVE_POSTS,
	SET_SKIP,
	SET_UNFOLLOW,
	SET_FOLLOW,
	SET_USER,
	SET_POSTS,
	SET_LOADING,
	SET_COMMENT,
	SET_DELETE,
	SET_DISLIKE,
	SET_LIKE,
} = profile.actions;
export default profile.reducer;
