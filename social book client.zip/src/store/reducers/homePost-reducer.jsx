import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	loading: false,
	posts: [],
	limit: 3,
	skip: 0,
};

const homePosts = createSlice({
	name: "homePosts",
	initialState,
	reducers: {
		SET_POSTS: (state, action) => {
			state.posts = action.payload.posts;
			state.skip = state.skip + 3;
		},
		ADD_POST : (state , action) => {
          state.posts = [action.payload.post , ...state.posts]
		},
		SET_LOADING: (state, action) => {
			state.loading = action.payload.loading;
		},
		SET_LIKE: (state, action) => {
			for (let post of state.posts) {
				if (post._id === action.payload.postId) {
					const index = post.likes.findIndex(
						(like) => like._id === action.payload.user._id
					);					
					index === -1 && post.likes.push(action.payload.user);
					break;
				}
			}
		},
		SET_DISLIKE: (state, action) => {
			for (let post of state.posts) {
				if (post._id === action.payload.postId) {
					const index = post.likes.findIndex(
						(like) => like._id === action.payload.userId
					);				
					 index !== -1 && post.likes.splice(index, 1);
					break;
				}
			}
		},
		SET_COMMENT: (state, action) => {
			state.posts.map((post) => {
				if (post._id === action.payload.postId) {
					post.comments.unshift(action.payload.user);
				}
			});
		},
		SET_DELETE: (state, action) => {
			state.posts = state.posts.filter(
				(post) => post._id !== action.payload.postId
			);
		},
		REMOVE_POSTS : (state , action) => {
			state.posts = [];
			state.skip = 0;
		}
	},
});

export const {
	REMOVE_POSTS,
	SET_POSTS,
	SET_LOADING,
	SET_DISLIKE,
	SET_LIKE,
	SET_COMMENT,
	SET_DELETE,
	ADD_POST,
} = homePosts.actions;
export default homePosts.reducer;
