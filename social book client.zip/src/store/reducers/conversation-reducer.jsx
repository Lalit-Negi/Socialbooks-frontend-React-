import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	messageCount: 0,
	users: [],
	messages: {},
};

const conversation = createSlice({
	name: "conversation",
	initialState,
	reducers: {
		ADD_USER: (state, action) => {
			const index = state.users.findIndex(
				(user) => user._id === action.payload.user._id
			);
			if (index === -1) {
				state.users.unshift(action.payload.user);
				state.messages[action.payload.user._id] = [];
			}
		},
		ADD_MESSAGE: (state, action) => {
			const user = state.messages[action.payload.userId];
			if (user) {
				state.messages[action.payload.userId].push(action.payload.message);
			}
			state.messageCount = state.messageCount + 1;
		},
		REMOVE_USER: (state, action) => {
			state.users = state.users.filter(
				(user) => user._id !== action.payload.userId
			);
		},
		SET_LAST_MESSAGE: (state, action) => {
			const index = state.users.findIndex(
				(user) => user._id === action.payload.userId
			);
			if (index !== -1) {
				state.users[index].lastMessage = action.payload.lastMessage;
			}
		},
		SET_MESSAGE_COUNT: (state, action) => {
			state.messageCount = action.payload.messageCount;
		},
		SET_USER_MESSAGE_COUNT: (state, action) => {
			state.users.forEach((user) => {
				if (user._id === action.payload.userId) {
					user.count = user.count + 1;
				}
			});
		},
		SET_USER_MESSAGE_COUNT_TO_ZERO: (state, action) => {
			state.users.forEach((user) => {
				if (user._id === action.payload.userId) {
					user.count = 0;
				}
			});
		},
		SET_ACTIVE: (state, action) => {
			state.users.forEach((user) => {
				if (user._id === action.payload.userId) {
					user.active = action.payload.active;
				}
			});
		},
		SET_LASTSEEN: (state, action) => {
			for (let user of state.users) {
				if (user._id === action.payload.userId) {
					user.lastSeen = action.payload.lastSeen;
					break;
				}
			}
		},
		REMOVE_ALL: (state, action) => {
			state.posts = [];
			state.messages = {};
			state.messageCount = 0;
		},
		SET_ISSENT: (state, action) => {
			for (let message of state.messages[action.payload.userId]) {
				if (message.time === action.payload.time) {
					message.isSent = true;
					break;
				}
			}
		},
		REMOVE_ALL_MESSAGES: (state, action) => {
			state.messages[action.payload.userId] = [];
		},
	},
});

export const {
	REMOVE_ALL_MESSAGES,
	SET_ISSENT,
	REMOVE_ALL,
	SET_LASTSEEN,
	ADD_USER,
	ADD_MESSAGE,
	REMOVE_USER,
	SET_LAST_MESSAGE,
	SET_MESSAGE_COUNT,
	SET_USER_MESSAGE_COUNT,
	SET_USER_MESSAGE_COUNT_TO_ZERO,
	SET_ACTIVE,
} = conversation.actions;
export default conversation.reducer;
