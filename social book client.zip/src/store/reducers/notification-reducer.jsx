import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	isNotification: false,
	loading: false,
	notification: [],
	skip: 0,
};

const notification = createSlice({
	name: "notification",
	initialState,
	reducers: {
		SET_NOTIFICATION: (state, action) => {
			state.notification = action.payload.notification;
			state.skip = state.skip + 1;
		},
		ADD_NOTIFICATION: (state, action) => {
			state.notification = [action.payload.notification, ...state.notification];
		},
		SET_IS_NOTIFICATION: (state, action) => {
			state.isNotification = action.payload.isNotification;
		},
	},
});

export const { SET_NOTIFICATION, ADD_NOTIFICATION, SET_IS_NOTIFICATION } =
	notification.actions;
export default notification.reducer;
