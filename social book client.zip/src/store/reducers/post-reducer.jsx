import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	loading: true,
	post: null,
};

const post = createSlice({
	name: "post",
	initialState,
	reducers: {
		SET_POST: (state, action) => {
			state.post = action.payload.post;
		},
		SET_LIKE: (state, action) => {
			const index = state.post.likes.findIndex(
				(like) => like._id === action.payload.user._id
			);
			index === -1 && state.post.likes.push(action.payload.user);
		},
		SET_DISLIKE: (state, action) => {
			state.post.likes = state.post.likes.filter(
				(like) => like._id !== action.payload.userId
			);
		},
		SET_COMMENT: (state, action) => {
			state.post.comments.unshift(action.payload.user);
		},
		SET_DELETE: (state, action) => {
			state.post = null;
		},
		SET_LOADING: (state, action) => {
			state.loading = action.payload.loading;
		},
	},
});

export const {
	SET_POST,
	SET_LIKE,
	SET_DISLIKE,
	SET_COMMENT,
	SET_DELETE,
	SET_LOADING,
} = post.actions;
export default post.reducer;
