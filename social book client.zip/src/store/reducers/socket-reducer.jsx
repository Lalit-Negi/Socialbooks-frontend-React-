import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	socket: null,
};

const socketConnection = createSlice({
	name: "socketConnection",
	initialState,
	reducers: {
		SET_SOCKET: (state, action) => {
			state.socket = action.payload.socket;
		},
	},
});

export const { SET_SOCKET } = socketConnection.actions;
export default socketConnection.reducer;
