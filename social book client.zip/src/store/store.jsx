import { configureStore } from "@reduxjs/toolkit";
import auth from "./reducers/auth-reducer";
import socketConnection from "../store/reducers/socket-reducer";
import notify from "./reducers/notify-reducer";
import homePosts from "./reducers/homePost-reducer";
import explorePosts from "./reducers/explorePosts-reducer";
import profile from "./reducers/profile-reducer";
import notification from "./reducers/notification-reducer";
import post from "./reducers/post-reducer";
import conversation from "./reducers/conversation-reducer";
import suggestions from "./reducers/suggestions-reducer";

export const store = configureStore({
	reducer: {
		auth,
		socketConnection,
		notify,
		homePosts,
		explorePosts,
		profile,
		notification,
		post,
		conversation,
		suggestions,
	},
});
