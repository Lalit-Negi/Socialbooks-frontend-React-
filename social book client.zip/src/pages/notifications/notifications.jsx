import React, { useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import NotificationCard from "./notification-card";
import PostLoader from "../../components/post-loader";
import Sidebar from "../../components/sidebar";
import { useSelector } from "react-redux";

const Notification = () => {
	const [isMore, setIsMore] = useState(false);
	const notification = useSelector((state) => state.notification);

	return (
		<div className="flex">
			<Sidebar />

			<div
				className="shadow-xl w-full p-2 md:p-4 h-screen overflow-y-scroll v-animation max-w-screen-sm lg:ml-16"
				id="scrollableDiv">
				<InfiniteScroll
					dataLength={notification.notification.length}
					next={""}
					hasMore={isMore}
					scrollableTarget="scrollableDiv">
					{notification.notification.length > 0 ? (
						notification.notification.map((notification, key) => {
							return (
								<NotificationCard
									key={key}
									profile={notification.profile}
									text={notification.text}
									link={notification.link}
									time={notification.createdAt}
									isRead={notification.isRead}
								/>
							);
						})
					) : (
						<p className="text-lg text-slate-500 first-letter:capitalize mt-6 text-center">
							no notifications
						</p>
					)}
				</InfiniteScroll>

				{notification.loading && <PostLoader />}
			</div>
		</div>
	);
};

export default Notification;
