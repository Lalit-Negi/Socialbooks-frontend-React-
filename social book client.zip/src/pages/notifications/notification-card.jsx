import React from "react";
import { Link } from "react-router-dom";
import moment from "moment";

const NotificationCard = ({ profile, text, link, time, isRead }) => {
	return (
		<div
			className={`${
				isRead ? "" : "bg-slate-50"
			} flex items-center relative space-x-3 p-4 hover:glass duration-300 transition-all ease-linear rounded-xl border-b border-b-slate-100`}>
			<div className="w-10 h-10 rounded-full overflow-hidden">
				<img src={profile} alt="" className="w-full h-full object-cover" />
			</div>
			<Link to={link} className="flex-1">
				<p className="text-slate-700 text-[15px]">{text}</p>
			</Link>
			<span className="text-[10px] text-slate-600 absolute bottom-1 right-1 bg-slate-100 py-1 px-3 rounded-full">
				{moment(time).fromNow("LTS")}
			</span>
		</div>
	);
};

export default NotificationCard;
