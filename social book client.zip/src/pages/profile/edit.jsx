import { useState } from "react";
import { user } from "../../constant/constant";
import { updateProfile } from "../../http/api";
import { useDispatch, useSelector } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import { SET_USER } from "../../store/reducers/auth-reducer";
import { SET_USER as SET_USER_PROFILE } from "../../store/reducers/profile-reducer";
import { useNavigate, useParams } from "react-router-dom";

const Edit = ({ openEdit, setOpenEdit }) => {
	const [name, setName] = useState("");
	const [bio, setBio] = useState("");
	const [profile, setProfile] = useState("");
	const dispatch = useDispatch();
	const CurrentProfile = useSelector((state) => state.profile);

	const handleSubmit = async () => {
		let data = {};

		if (name.length >= 3) {
			data.name = name;
		}
		if (bio) {
			data.bio = bio;
		}
		if (profile) {
			data.profile = profile;
		}

		if (name && name.length < 3) {
			alert("name must be 3 character long");
			return;
		}

		if (data.name || data.bio || data.profile) {
			try {
				dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
				const res = await updateProfile(data);
				dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
				if (res.status === 201) {
					dispatch(SET_NOTIFY({ notifyType: { success: res.data.messgae } }));

					if (CurrentProfile.user?._id === res.data.user._id) {
						dispatch(SET_USER_PROFILE({ user: res.data.user }));
					}
					dispatch(SET_USER({ user: res.data.user }));
				}

				if (res.status !== 201) {
					dispatch(SET_NOTIFY({ notifyType: { error: res.data.messgae } }));
				}
			} catch (error) {
				dispatch(SET_NOTIFY({ notifyType: { error: error.messgae } }));
			}
		} else {
			dispatch(SET_NOTIFY({ notifyType: { error: "No data to change" } }));
			return;
		}
	};

	const handleProfile = (e) => {
		const image = e.target.files[0];
		const reader = new FileReader();
		reader.readAsDataURL(image);
		reader.onload = function (e) {
			setProfile(e.target.result);
		};
		reader.onerror = () => {
			alert("try after some time");
		};
	};

	return (
		<div
			className={
				openEdit
					? "bg-slate-100 fixed md:absolute top-6 left-4 right-4 flex flex-col space-y-4 p-4 rounded-md z-40 v-animation border border-slate-300 shadow-2xl"
					: "hidden"
			}>
			<span className="ml-auto" onClick={() => setOpenEdit((prev) => !prev)}>
				<svg
					fill="gray"
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="35"
					height="35">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
				</svg>
			</span>

			<div className="p-4 bg-white rounded-md shadow-sm">
				<input
					type="text"
					placeholder="name"
					className="bg-transparent w-full outline-none"
					value={name}
					onChange={(e) => setName(e.target.value)}
				/>
			</div>
			<div className="p-4 bg-white rounded-md shadow-sm">
				<textarea
					type="text"
					placeholder="bio"
					className="bg-transparent w-full outline-none"
					value={bio}
					rows="2"
					onChange={(e) => setBio(e.target.value)}
				/>
			</div>
			<div className="p-4 bg-white rounded-md flex flex-col items-center shadow-sm">
				<div className="w-24 h-24 rounded-full overflow-hidden shadow-2xl">
					<img
						src={profile ? profile : user}
						alt=""
						className="w-full h-full object-cover"
					/>
				</div>
				<label htmlFor="profile" className="text-blue-700 underline">
					select profile
				</label>
				<input
					id="profile"
					type="file"
					accept="image/*"
					className="hidden"
					onChange={handleProfile}
				/>
			</div>

			<div className="text-white rounded-md flex justify-end">
				<button
					className="bg-main text-xs sm:text-md sm:py-2 py-1 px-3 sm:px-7 rounded-md shadow-lg hover:scale-105 transition-all duration-900"
					onClick={handleSubmit}>
					Change
				</button>
			</div>
		</div>
	);
};

export default Edit;
