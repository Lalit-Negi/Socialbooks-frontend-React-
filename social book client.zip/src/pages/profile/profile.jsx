import React, { useEffect, useState } from "react";
import Sidebar from "../../components/sidebar";
import User from "./user";
import Post from "../../components/home/posts/post";
import {
	userProfile,
	userPosts,
	follow,
	unFollow,
	createNotification,
} from "../../http/api";
import { useSelector, useDispatch } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import InfiniteScroll from "react-infinite-scroll-component";
import { likePost, commentPost, deletePost, dislikePost } from "../../http/api";
import {
	SET_SKIP,
	SET_LIKE,
	SET_DELETE,
	SET_DISLIKE,
	SET_LOADING,
	SET_POSTS,
	SET_USER,
	SET_COMMENT,
	SET_FOLLOW,
	SET_UNFOLLOW,
} from "../../store/reducers/profile-reducer";
import { useParams } from "react-router-dom";
import Edit from "./edit";
import PostLoader from "../../components/post-loader";
import {
	SET_UNFOLLOWING,
	SET_FOLLOWING,
} from "../../store/reducers/auth-reducer";
import { useNavigate } from "react-router-dom";
import { ADD_USER } from "../../store/reducers/conversation-reducer";

const Profile = () => {
	const [isMore, setIsMore] = useState(true);
	const dispatch = useDispatch();
	const profile = useSelector((state) => state.profile);
	const auth = useSelector((state) => state.auth);
	let { userId } = useParams();
	const [openEdit, setOpenEdit] = useState(false);
	const [isFollowed, setIsFollowed] = useState();
	const socket = useSelector((state) => state.socketConnection.socket);
	const navigate = useNavigate();

	useEffect(() => {
		auth.user.following.forEach((user) => {
			if (user._id === profile.user?._id) {
				setIsFollowed(true);
			}
		});
	}, [profile.user]);

	const getProfile = async () => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await userProfile(userId);
			dispatch(SET_NOTIFY({ notifyType: { loading: false } }));
			if (res.status === 200) {
				dispatch(SET_USER({ user: res.data.user }));
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const fetchPosts = async () => {
		try {
			dispatch(SET_LOADING({ loading: true }));
			const res = await userPosts({
				limit: profile.limit,
				skip: profile.skip,
				userId,
			});
			dispatch(SET_LOADING({ loading: false }));
			if (res.status === 200) {
				if (res.data.posts.length === 0) {
					setIsMore(false);
				}
				dispatch(SET_POSTS({ posts: [...profile.posts, ...res.data.posts] }));
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const followUser = async (id) => {
		try {
			const res = await follow({ id });
			dispatch(
				SET_FOLLOW({
					user: {
						name: auth.user.name,
						profile: auth.user.profile,
						_id: auth.user._id,
					},
				})
			);
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				setIsFollowed(true);
				dispatch(
					SET_FOLLOWING({
						user: {
							name: profile.user?.name,
							profile: profile.user?.profile,
							_id: id,
						},
					})
				);

				socket.emit("FOLLOW", {
					user: {
						name: auth.user.name,
						profile: auth.user.profile,
						_id: auth.user._id,
					},
					_id: id,
				});

				try {
					const data = {
						text: `${auth.user.name} starting following you`,
						link: `/profile/${auth.user._id}`,
						recipient: [id],
						profile: auth.user.profile,
					};
					const res = await createNotification(data);
					if (res.status === 201) {
						socket.emit("FOLLOW_NOTIFICATION", res.data.notification);
					}
				} catch (error) {
					dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
				}
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
			setIsFollowed(false);
		}
	};

	const unFollowUser = async (id) => {
		try {
			const res = await unFollow({ id });
			dispatch(
				SET_UNFOLLOW({
					userId: auth.user._id,
				})
			);
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				setIsFollowed(false);
				dispatch(
					SET_UNFOLLOWING({
						userId: profile.user?._id,
					})
				);
				socket.emit("UNFOLLOW", { userId: auth.user._id, _id: id });
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
			setIsFollowed(false);
		}
	};

	useEffect(() => {
		if (userId === auth.user._id) {
			dispatch(SET_USER({ user: auth.user }));
		} else {
			getProfile();
		}

		fetchPosts();

		return () => {
			dispatch(SET_USER({ user: null }));
			dispatch(SET_POSTS({ posts: [] }));
			dispatch(SET_SKIP({ skip: 0 }));
		};
	}, []);

	const handleLike = async (postId) => {
		const user = {
			name: auth.user.name,
			profile: auth.user.profile,
			_id: auth.user._id,
		};

		dispatch(SET_LIKE({ postId, user }));

		try {
			const res = await likePost({ postId });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}
	};

	const handleDislike = async (postId) => {
		dispatch(
			SET_DISLIKE({
				postId,
				userId: auth.user._id,
			})
		);
		try {
			const res = await dislikePost({ postId });
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleComment = async (postId, comment, setComment) => {
		if (!comment) {
			return;
		}
		const user = {
			userComment: {
				name: auth.user.name,
				profile: auth.user.profile,
				_id: auth.user._id,
			},
			text: comment,
			createdAt: Date.now(),
		};

		try {
			const res = await commentPost({ postId, comment });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				dispatch(SET_COMMENT({ postId, user }));
			}
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}

		try {
			setComment((prev) => "");
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleDeletePost = async (postId, setRemovePost) => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await deletePost(postId);
			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 200) {
				dispatch(SET_DELETE({ postId }));
			}
			dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			setRemovePost(false);
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const handleMessaging = () => {
		dispatch(
			ADD_USER({
				user: {
					name: profile.user.name,
					profile: profile.user.profile,
					_id: profile.user._id,
					count: 0,
					lastMessage: "",
					lastSeen: "",
				},
			})
		);
		navigate("/chat");
	};

	return (
		<div className="flex"> 
			<Sidebar />

			<div
				className="max-w-screen-sm lg:ml-16 shadow-xl relative bg-white h-screen overflow-y-scroll px-2 py-4 sm:px-6 v-animation"
				id="scrollableDiv">
				<div className="shadow-sm">
					<User userDetail={profile.user} />

					{userId === auth.user._id ? (
						<div className="text-center py-4">
							<button
								onClick={() => setOpenEdit((prev) => !prev)}
								className="text-white w-[95%] py-2 px-4 bg-green-400 transition-all hover:bg-green-500 duration-300 hover:scale-105 rounded-md capitalize">
								Edit Profile
							</button>
							<Edit openEdit={openEdit} setOpenEdit={setOpenEdit} />
						</div>
					) : (
						<div className="flex space-x-3 xs:space-x-6 items-center py-1 pb-4 px-2 xs:px-4">
							{isFollowed ? (
								<button
									onClick={() => unFollowUser(profile.user._id)}
									className="flex-1 text-white py-2 px-4 bg-green-400 transition-all hover:bg-green-500 duration-300 hover:scale-105 rounded-md capitalize">
									unfollow
								</button>
							) : (
								<button
									onClick={() => followUser(profile.user._id)}
									className="flex-1 text-white py-2 px-4 bg-green-400 transition-all hover:bg-green-500 duration-300 hover:scale-105 rounded-md capitalize">
									follow
								</button>
							)}
							<button
								onClick={handleMessaging}
								className="flex-1 text-white py-2 px-4 bg-green-400 transition-all hover:bg-green-500 duration-300 hover:scale-105 rounded-md capitalize">
								message
							</button>
						</div>
					)}
				</div>

				<div className="mt-5">
					<InfiniteScroll
						dataLength={profile.posts.length}
						next={fetchPosts}
						hasMore={isMore}
						scrollableTarget="scrollableDiv"
						>
						{profile.posts.length > 0 ? (
							profile.posts.map((post, key) => {
								return (
									<Post
										post={post}
										key={key}
										handleLike={handleLike}
										handleDislike={handleDislike}
										handleComment={handleComment}
										handleDeletePost={handleDeletePost}
									/>
								);
							})
						) : (
							<div className="flex items-center flex-col">
								<h2 className="my-4 text-xl text-slate-500">No posts</h2>								
							</div>
						)}
					</InfiniteScroll>
					{profile.loading && <PostLoader />}
				</div>
			</div>
		</div>
	);
};

export default Profile;
