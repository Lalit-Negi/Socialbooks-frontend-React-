import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { REMOVE_POSTS } from "../../store/reducers/profile-reducer";

export const FriendsModel = ({ friends, openModel, setOpenModel }) => {
	const navigate = useNavigate();
	const dispatch = useDispatch();
	return (
		<div
			className={
				openModel
					? "bg-slate-100 fixed md:absolute h-[80vh] top-[10vh] left-2 right-2 sm:right-6 sm:left-6 shadow-2xl flex flex-col p-4 rounded-lg z-40 overflow-y-scroll v-animation"
					: "hidden"
			}>
			<span className="ml-auto mb-3 bg-slate-200 rounded-full" onClick={() => setOpenModel((prev) => !prev)}>
				<svg
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="32"
					height="32">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
				</svg>
			</span>
			{friends?.map((friend, key) => {
				return (
					<div
						className="flex mb-2 space-x-3 hover:glass bg-white transition-all duration-300 ease-linear p-4 rounded-lg"
						key={key}
						onClick={() => {
							dispatch(REMOVE_POSTS());
							navigate(`/profile/${friend._id}`);
						}}>
						<div className="rounded-full overflow-hidden xs:w-12 xs:h-12 w-9 h-9">
							<img
								src={friend?.profile}
								alt=""
								className="w-full h-full object-cover"
							/>
						</div>
						<p className="sm:text-[19px] text-xs mt-2 text-slate-700">{friend?.name}</p>
					</div>
				);
			})}
		</div>
	);
};

const User = ({ userDetail }) => {
	const [openFollowersModel, setOpenFollowersModel] = useState(false);
	const [openFollowingModel, setOpenFollowingModel] = useState(false);

	const bioMaker = (bio) => {
		let newBio = bio.split("\n");
		return newBio;
	};

	return (
		<>
			<div className="relative">
				<div className="flex space-x-3 xs:space-x-12">
					<div className="rounded-full h-[5rem] w-[5rem] xs:w-24 xs:h-24 overflow-hidden mt-1">
						<img
							src={userDetail?.profile}
							alt=""
							className="w-full h-full object-cover"
						/>
					</div>
					<div className="flex-1">
						<h3 className="text-xl pt-2 sm:pt-0 xs:text-3xl text-gray-700 font-serif">
							{userDetail?.name}
						</h3>
						<div className="flex space-x-2 md:space-x-6 my-3 text-gray-700">
							<div
								className="flex flex-col items-center cursor-pointer p-2"
								onClick={() => setOpenFollowersModel((prev) => !prev)}>
								<p>{userDetail?.followers.length}</p>
								<p className="text-xs md:text-sm">Followers</p>
							</div>
							<div
								className="flex flex-col items-center cursor-pointer p-2"
								onClick={() => setOpenFollowingModel((prev) => !prev)}>
								<p>{userDetail?.following.length}</p>
								<p className="text-xs md:text-sm">Following</p>
							</div>
						</div>
					</div>
				</div>

				<p className="text-slate-700 xs:text-[17px] text-[15px] tracking-wide leading-5 pl-2 my-2 font-serif">
					{userDetail?.bio &&
						bioMaker(userDetail?.bio).map((line, key) => (
							<p key={key}> {line}</p>
						))}
				</p>
			</div>

			<FriendsModel
				friends={userDetail?.followers}
				openModel={openFollowersModel}
				setOpenModel={setOpenFollowersModel}
			/>
			<FriendsModel
				friends={userDetail?.following}
				openModel={openFollowingModel}
				setOpenModel={setOpenFollowingModel}
			/>
		</>
	);
};

export default User;
