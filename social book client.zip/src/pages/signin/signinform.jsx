import React, { useState } from "react";
import Button from "../../components/button";
import Input from "../../components/input";
import Brand from "../../components/brand";
import Account from "../../components/account";
import { signIn } from "../../http/api";
import { SET_USER } from "../../store/reducers/auth-reducer";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer"

const SignInForm = () => {
	const [signInData, setSignInData] = useState({
		phone: "",
		password: "",
	});
	const navigate = useNavigate();
	const dispatch = useDispatch();

	const handleChange = (e) => {
		setSignInData((prev) => {
			return {
				...prev,
				[e.target.name]: e.target.value,
			};
		});
	};

	const clickHandler = async () => {
		if (signInData.phone.length <= 9) {			
			dispatch(SET_NOTIFY({notifyType : { error : "This number is not valid"}}))
			return;
		}
		if (!signInData.password) {			
			dispatch(SET_NOTIFY({notifyType : { error : "please fill password field"}}))
			return;
		}
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await signIn({
				phone: signInData.phone,
				password: signInData.password,
			});
			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 200 && res.data) {
				dispatch(SET_USER({ user: res.data }));
				navigate("/home");
				dispatch(SET_NOTIFY({ notifyType: { success : "login successfully"} }));
			}
		} catch (error) {		
			dispatch(
				SET_NOTIFY({ notifyType: { error: error.response.data.originalError } })
			);
		}
	};

	return (
		<div className="w-[fit-content] h-screen overflow-hidden mx-auto bg-white px-4 mt-16 v-animation">
			<Brand />
			<div className="rounded-lg px-4">
				<Input
					type="number"
					name="phone"
					placeHolder="Phone"
					handleChange={handleChange}
					value={signInData.phone}
				/>
				<Input
					type="password"
					name="password"
					placeHolder="Password"
					handleChange={handleChange}
					value={signInData.password}
				/>
				<Button
					text="Log In"
					display="block w-full"
					clickHandler={clickHandler}
				/>
				{/* <p className="text-sm text-center text-blue-600 mt-6 cursor-pointer underline">
					Forgett Password?
				</p> */}
			</div>
			<Account
				to="/signup"
				text1="Don't have any account?"
				text2="SignUp Now"
			/>
		</div>
	);
};

export default SignInForm;
