import React, { useState } from "react";
import { user } from "../../constant/constant";
import Button from "../../components/button";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { signUp } from "../../http/api";
import { SET_USER } from "../../store/reducers/auth-reducer";
import { useNavigate } from "react-router-dom";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";

const Profile = () => {
	const [profile, setProfile] = useState(user);
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const signUpData = useSelector((state) => state.auth.signUp);

	const onChangeHandler = (e) => {
		const image = e.target.files[0];
		if (image.size > 15400000) {
			dispatch(
				SET_NOTIFY({ notifyType: { error: "image size is greater then 5mb" } })
			);
			return;
		}
		const reader = new FileReader();
		reader.readAsDataURL(image);
		reader.onload = (event) => {
			setProfile(event.target.result);
		};
		reader.onerror = (event) => {
			console.log("File could not be read: " + event.target.error);
			dispatch(
				SET_NOTIFY({
					notifyType: { error: "something error with profile image" },
				})
			);
		};
	};

	const clickHandler = async () => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await signUp({
				name: signUpData.name,
				password: signUpData.password,
				confirmPassword: signUpData.confirmPassword,
				bio: signUpData.bio || "",
				profile,
			});

			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 201 && res.data) {
				dispatch(SET_USER({ user: res.data }));
				navigate("/home");
				dispatch(
					SET_NOTIFY({ notifyType: { success: "signUp successfully" } })
				);
			}
			if (res.error) {
				dispatch(
					SET_NOTIFY({
						notifyType: { error: error.response.data.originalError },
					})
				);
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	return (
		<div className="flex flex-col items-center max-w-[500px] mt-4 v-animation">
			<div className="w-[180px] h-[180px] overflow-hidden rounded-full border-[4px] border-main ">
				<img
					src={profile}
					alt="profile"
					className="object-cover w-full h-full"
				/>
			</div>
			<div className="py-4 flex justify-center ">
				<label
					htmlFor="profile"
					className="text-center underline text-blue-600">
					select profile
				</label>
				<input
					type="file"
					id="profile"
					accept="image/*"
					className="hidden"
					onChange={(e) => onChangeHandler(e)}
				/>
			</div>
			<Button
				text="continue"
				display="block w-[200px]"
				clickHandler={clickHandler}
			/>
		</div>
	);
};

export default Profile;
