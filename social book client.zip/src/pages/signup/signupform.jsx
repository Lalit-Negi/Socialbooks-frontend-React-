import React, { useState } from "react";
import Input from "../../components/input";
import Button from "../../components/button";
import TextArea from "../../components/textarea";
import Profile from "./profile";
import Account from "../../components/account";
import { SET_SIGNUP_DATA } from "../../store/reducers/auth-reducer";
import { useDispatch } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";

const SignUpForm = ({ setSignUpStep }) => {
	const [signUpForm, setSignUpForm] = useState({
		name: "",
		password: "",
		confirmPassword: "",
		bio: "",
	});

	const dispatch = useDispatch();

	const handleChange = (e) => {
		setSignUpForm((prev) => {
			return {
				...prev,
				[e.target.name]: e.target.value,
			};
		});
	};

	const clickHandler = () => {
		if (signUpForm.name.length <= 2) {
			dispatch(
				SET_NOTIFY({
					notifyType: { error: "Name must be 3 charaters atleast" },
				})
			);
			return;
		} else if (signUpForm.password.length <= 5) {
			dispatch(
				SET_NOTIFY({ notifyType: { error: "Password must be 6 charaters" } })
			);
			return;
		} else if (signUpForm.confirmPassword !== signUpForm.password) {
			dispatch(
				SET_NOTIFY({
					notifyType: { error: "Confirm password and password didn't matched" },
				})
			);
			return;
		} else {
			dispatch(
				SET_SIGNUP_DATA({
					name: signUpForm.name,
					password: signUpForm.password,
					confirmPassword: signUpForm.confirmPassword,
					bio: signUpForm.bio || "",
				})
			);
			setSignUpStep((prev) => prev + 1);
		}
	};

	return (
		<div className="w-[fit-content] v-animation">
			<div className="rounded-lg">
				<Input
					name="name"
					type="text"
					placeHolder="Name"					
					value={signUpForm.name}
					handleChange={handleChange}
				/>
				<Input
					type="password"
					name="password"
					placeHolder="Password"
					value={signUpForm.password}
					handleChange={handleChange}
				/>
				<Input
					type="password"
					name="confirmPassword"
					placeHolder="Confirm Password"
					value={signUpForm.confirmPassord}
					handleChange={handleChange}
				/>
				<TextArea
					name="bio"
					placeHolder="Short Description"
					value={signUpForm.bio}
					handleChange={handleChange}
				/>
				<Button
					text="Sign Up"
					display="block w-full"
					clickHandler={clickHandler}
				/>
			</div>
			<Account to="/" text1="Have an account?" text2="Sign In now" />
		</div>
	);
};

export default SignUpForm;
