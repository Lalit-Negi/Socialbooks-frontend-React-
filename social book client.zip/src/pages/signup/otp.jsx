import React, { useState } from "react";
import Input from "../../components/input";
import Button from "../../components/button";
import Account from "../../components/account";
import { useDispatch, useSelector } from "react-redux";
import { verifyOtp } from "../../http/api";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";

const Otp = ({ setSignUpStep }) => {
	const [otp, setOtp] = useState("");
	const signUpData = useSelector((state) => state.auth.signUp);
	const dispatch = useDispatch();

	const handleChange = (e) => {
		setOtp((prev) => e.target.value);
	};

	const clickHandler = async () => {
		if (otp) {
			try {
				dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
				const { data } = await verifyOtp({
					hash: signUpData.hash,
					phone: signUpData.phone,
					otp,
				});
				dispatch(SET_NOTIFY({ notifyType: {} }));
				if (data.auth) {
					setSignUpStep((prev) => prev + 1);
				}
			} catch (error) {
				console.log(error);
				dispatch(
					SET_NOTIFY({
						notifyType: { error: error.response.data.originalError },
					})
				);
			}
		} else {
			alert("please fill otp field");
			return;
		}
	};

	return (
		<div className="flex flex-col items-center v-animation">
			<h3 className="text-slate-600 text-lg">your otp is - {signUpData.otp}</h3>
			<Input type="number" placeHolder="Otp" handleChange={handleChange} />
			<Button
				text="continue"
				display="block w-full"
				clickHandler={clickHandler}
			/>
			<Account to="/" text1="Have an account?" text2="Sign In now" />
		</div>
	);
};

export default Otp;
