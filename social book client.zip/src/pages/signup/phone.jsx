import React, { useState } from "react";
import Button from "../../components/button";
import Input from "../../components/input";
import Account from "../../components/account";
import { SET_PHONE, SET_HASH , SET_OTP } from "../../store/reducers/auth-reducer";
import { useDispatch } from "react-redux";
import { sendOtp } from "../../http/api";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer"

const Phone = ({ setSignUpStep }) => {
	const [phone, setPhone] = useState("");

	const dispatch = useDispatch();

	const handleChange = (e) => {
		setPhone((prev) => e.target.value);
	};

	const clickHandler = async () => {
		if (phone.length <= 9) {
			dispatch(SET_NOTIFY({ notifyType: { error: "This is not a valid contact number" } }));
			return
		}
		dispatch(SET_PHONE({ phone }));
		try { 
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const { data } = await sendOtp({ phone });
			dispatch(SET_NOTIFY({ notifyType: { } }));
			if (data && data.hash) {
				dispatch(SET_HASH({ hash: data.hash }));
				dispatch(SET_OTP({ otp: data.otp }));
				setSignUpStep((prev) => prev + 1);
			}
		} catch (error) {
			console.log(error.message);		
			dispatch(SET_NOTIFY({ notifyType: { error : error.response.data.originalError} }));
		}
	};

	return (
		<div className="flex flex-col items-center v-animation">
			<Input
				type="number"
				placeHolder="Phone"
				value={phone}
				handleChange={handleChange}
			/>
			<Button
				text="continue"
				display="block w-full"
				clickHandler={clickHandler}
			/>
			<Account to="/" text1="Have an account?" text2="Sign In now" />
		</div>
	);
};

export default Phone;
