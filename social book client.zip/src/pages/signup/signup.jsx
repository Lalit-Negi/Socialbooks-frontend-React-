import React from "react";
import { useState } from "react";
import Phone from "./phone";
import SignUpForm from "./signupform";
import Profile from "./profile";
import Otp from "./otp";
import Brand from "../../components/brand";

const SignUp = () => {
	const [signUpStep, setSignUpStep] = useState(1);

	const signUpSteps = {
		1: <Phone setSignUpStep={setSignUpStep} />,
		2: <Otp setSignUpStep={setSignUpStep} />,
		3: <SignUpForm setSignUpStep={setSignUpStep} />,
		4: <Profile setSignUpStep={setSignUpStep} />,
	};

	return (
		<div className="grid place-items-center h-screen v-animation">
			<div>
				<Brand />
				{signUpSteps[signUpStep]}
			</div>
		</div>
	);
};

export default SignUp;
