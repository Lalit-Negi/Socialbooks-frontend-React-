import React, { useEffect, useState } from "react";
import Sidebar from "../../components/sidebar";
import Search from "./search";
import PostLoader from "../../components/post-loader";
import InfiniteScroll from "react-infinite-scroll-component";
import Post from "../../components/home/posts/post";
import { useSelector, useDispatch } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import {
	SET_LOADING,
	SET_POSTS,
	SET_LIKE,
	SET_DISLIKE,
	SET_DELETE,
	SET_COMMENT,
} from "../../store/reducers/explorePosts-reducer";
import {
	explore,
	likePost,
	dislikePost,
	deletePost,
	commentPost,
	suggestions,
} from "../../http/api";
import Suggestions from "../../components/suggestions";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import {
	SET_USERS as SET_SUGGEST_USERS,
	SET_LOADING as SET_SUGGEST_LOADING,
} from "../../store/reducers/suggestions-reducer";

const Explore = () => {
	const explorePosts = useSelector((state) => state.explorePosts);
	const auth = useSelector((state) => state.auth);
	const dispatch = useDispatch();
	const [isMore, setIsMore] = useState(true);
	const suggest = useSelector((state) => state.suggestions);

	const handleLike = async (postId) => {
		const user = {
			name: auth.user.name,
			profile: auth.user.profile,
			_id: auth.user._id,
		};

		dispatch(SET_LIKE({ postId, user }));

		try {
			const res = await likePost({ postId });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}
	};

	const handleDislike = async (postId) => {
		dispatch(
			SET_DISLIKE({
				postId,
				userId: auth.user._id,
			})
		);
		try {
			const res = await dislikePost({ postId });
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleComment = async (postId, comment, setComment) => {
		if (!comment) {
			return;
		}
		const user = {
			userComment: {
				name: auth.user.name,
				profile: auth.user.profile,
				_id: auth.user._id,
			},
			text: comment,
			createdAt: Date.now(),
		};

		try {
			const res = await commentPost({ postId, comment });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				dispatch(SET_COMMENT({ postId, user }));
			}
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}

		try {
			setComment((prev) => "");
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleDeletePost = async (postId, setRemovePost) => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await deletePost(postId);
			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 200) {
				dispatch(SET_DELETE({ postId }));
			}
			dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			setRemovePost(false);
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const fetchPosts = async () => {
		try {
			dispatch(SET_LOADING({ loading: true }));
			const res = await explore({
				limit: explorePosts.limit,
				skip: explorePosts.skip,
			});
			if (res.status === 200) {
				if (res.data.explore.length === 0) {
					setIsMore(false);
					dispatch(SET_LOADING({ loading: false }));
					return;
				}
				dispatch(
					SET_POSTS({ posts: [...explorePosts.posts, ...res.data.explore] })
				);
				dispatch(SET_LOADING({ loading: false }));
			}
		} catch (error) {
			dispatch(SET_LOADING({ loading: false }));
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const fetchSuggestions = async () => {
		dispatch(SET_SUGGEST_LOADING({ loading: true }));
		let alreadySeen = auth.user.following.map((user) => user._id);
		alreadySeen = [...alreadySeen, ...suggest.users.map((user) => user._id)];
		try {
			const res = await suggestions({ alreadySeen });
			if (res.status === 200) {
				dispatch(SET_SUGGEST_LOADING({ loading: false }));
				dispatch(
					SET_SUGGEST_USERS({ users: [...res.data.users, ...suggest.users] })
				);
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	useEffect(() => {
		if (explorePosts.posts.length === 0) {
			fetchPosts();
		}

		if (suggest.users.length === 0) {
			fetchSuggestions();
		}
	}, []);

	return (
		<div className="flex">
			<Sidebar />

			<div
				className="shadow-xl flex-1 h-screen overflow-y-scroll p-2 v-animation max-w-screen-sm lg:ml-16"
				id="scrollableDiv">
				<Search />

				<div className="flex space-x-2">
					<h2 className="px-4 py-1 rounded-full mb-2 text-slate-700 bg-slate-200 w-[fit-content]">
						Suggestions
					</h2>
					<span>
						<svg
							onClick={() => fetchSuggestions()}
							className={`fill-slate-400 mt-1 ${
								suggest.loading && "animate-spin"
							}`}
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 24 24"
							width="28"
							height="28">
							<path fill="none" d="M0 0h24v24H0z" />
							<path d="M18.537 19.567A9.961 9.961 0 0 1 12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10c0 2.136-.67 4.116-1.81 5.74L17 12h3a8 8 0 1 0-2.46 5.772l.997 1.795z" />
						</svg>
					</span>
				</div>

				<Swiper
					spaceBetween={10}
					slidesPerView={
						window.innerWidth > 480 ? 4 : window.innerWidth > 360 ? 3 : 2
					}
					className="swiper py-2 px-2">
					{suggest.users.map((user, key) => (
						<SwiperSlide key={key}>
							<Suggestions
								name={user.name}
								profile={user.profile}
								_id={user._id}
							/>
						</SwiperSlide>
					))}
				</Swiper>

				<InfiniteScroll
					dataLength={explorePosts.posts.length}
					next={fetchPosts}
					hasMore={isMore}
					scrollableTarget="scrollableDiv"
					>
					{explorePosts.posts.length > 0 ? (
						explorePosts.posts.map((post, key) => {
							return (
								<Post
									post={post}
									key={key}
									handleLike={handleLike}
									handleDislike={handleDislike}
									handleComment={handleComment}
									handleDeletePost={handleDeletePost}
								/>
							);
						})
					) : (
						<div className="flex items-center flex-col">
							<h2 className="my-4 text-xl text-slate-500">No posts</h2>							
						</div>
					)}
				</InfiniteScroll>

				{explorePosts.loading && <PostLoader />}
			</div>
		</div>
	);
};

export default Explore;
