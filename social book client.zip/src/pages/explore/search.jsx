import React, { useEffect, useRef } from "react";
import { useState } from "react";
import { searchUser } from "../../http/api";
import { useNavigate } from "react-router-dom";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import { useDispatch } from "react-redux";

const Search = () => {
	const search = useRef();
	const [searchedUsers, setSearchedUsers] = useState([]);
	const navigate = useNavigate();
	const dispatch = useDispatch();

	const handleSearch = async () => {
		if (!search.current.value) {
			return;
		}
		try {
			const res = await searchUser({ query: search.current.value });
			if (res.status === 200) {
				setSearchedUsers((prev) => res.data.results);
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	useEffect(() => {
		let check = setInterval(() => {
			if (search.current.value.length === 0) {
				setSearchedUsers((prev) => []);
			}
		}, 1000);

		return () => clearInterval(check);
	}, []);

	return (
		<div className="relative">
			<div className="flex items-center sticky top-0 bg-white pt-8 pb-8">
				<div className="flex-1">
					<input
						ref={search}
						type="text"
						placeholder="Find user ..."
						className="bg-slate-100 py-2 px-4 w-full rounded-lg  focus:outline-none text-gray-600 caret-black"
						onChange={handleSearch}
					/>
				</div>
				<div className="ml-3">
					<button
						className="bg-main hover:bg-hover py-2 px-2 md:px-6 text-white rounded-lg"
						onClick={handleSearch}
						onKeyUp={(e) => {
							if (e.key === "Enter") {
								handleSearch();
							}
						}}>
						<svg
							fill="white"
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 24 24"
							width="24"
							height="24">
							<path fill="none" d="M0 0h24v24H0z" />
							<path d="M11 2c4.968 0 9 4.032 9 9s-4.032 9-9 9-9-4.032-9-9 4.032-9 9-9zm0 16c3.867 0 7-3.133 7-7 0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7zm8.485.071l2.829 2.828-1.415 1.415-2.828-2.829 1.414-1.414z" />
						</svg>
					</button>
				</div>
			</div>

			<div className={`${searchedUsers.length > 0 && "md:p-6 h-[70vh]" } glass bg-white rounded-md absolute right-0 left-0 top-[80%] v-animation z-50`}>
				{searchedUsers.length > 0 && (
					searchedUsers.map((user, key) => {
						return (
							<div
								className="flex space-x-2 items-center md:space-x-4 hover:glass hover:cursor-pointer duration-300 transition-all p-4 rounded-lg ease-linear"
								onClick={() => navigate(`/profile/${user._id}`)}
								key={key}>
								<div className="md:w-12 md:h-12 w-9 h-9 overflow-hidden rounded-full v-animation">
									<img
										src={user.profile}
										alt=""
										className="w-full h-full object-cover"
									/>
								</div>
								<p className="text-gray-700 text-sm">{user.name}</p>
							</div>
						);
					})
				)}
			</div>
		</div>
	);
};

export default Search;
