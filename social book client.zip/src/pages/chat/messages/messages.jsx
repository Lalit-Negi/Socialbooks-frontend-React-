import React from "react";
import MessageNav from "./message-nav";
import Message from "./message";
import MessageSender from "./message-sender";
import { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
	ADD_MESSAGE,
	SET_ISSENT,
	SET_LAST_MESSAGE,
} from "../../../store/reducers/conversation-reducer";
import api, { transferMessage, getMessages } from "../../../http/api";
import Compressor from "compressorjs";
import { SET_NOTIFY } from "../../../store/reducers/notify-reducer";

const Messages = ({ switchScreen, userId }) => {
	const [user, setUser] = useState(null);
	const { users: allUsers, messages } = useSelector(
		(state) => state.conversation
	);
	const navigate = useNavigate();
	const socket = useSelector((state) => state.socketConnection.socket);
	const scrollRef = useRef();
	const dispatch = useDispatch();
	const auth = useSelector((state) => state.auth);

	useEffect(() => {
		const user = allUsers.find((user) => user._id === userId);
		if (user) {
			setUser(user);
		} else {
			navigate("/chat");
		}
	}, []);

	useEffect(() => {
		if (messages[userId].length > 0) {
			return;
		} else {
			(async () => {
				const res = await getMessages({ userId: userId });
				if (res.status === 200) {
					res.data.messages.forEach((msz) => {
						dispatch(ADD_MESSAGE({ message: msz, userId }));
					});
				}
			})();
		}
	}, []);

	useEffect(() => {
		scrollRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages[userId]]);

	const sendMessage = async (msz) => {
		if (msz.media === "text") {
			const data = {
				sender: auth.user._id,
				recipient: userId,
				...msz,
			};

			dispatch(
				ADD_MESSAGE({ message: { ...data, isSent: false }, userId: user._id })
			);
			dispatch(SET_LAST_MESSAGE({ lastMessage: data, userId: user._id }));

			try {
				const res = await transferMessage({
					recipient: user._id,
					message: data,
				});
				if (res.status === 201) {
					dispatch(SET_ISSENT({ userId, time: msz.time }));
					socket.emit("MESSAGE", {
						user: {
							name: auth.user.name,
							profile: auth.user.profile,
							_id: auth.user._id,
						},
						lastMessage: data,
						...data,
					});
				}
			} catch (error) {
				console.log(error.message);
			}
		}

		if (msz.media === "video" || msz.media === "image") {
			const uploadFile = async (data) => {
				try {
					const res = await api({
						url: "/api/messagefile",
						method: "patch",
						headers: {
							"Content-Type": "multipart/form-data",
							Accept: "application/json",
						},
						data: data,
					});

					if (res.status === 201) {
						dispatch(SET_ISSENT({ userId, time: msz.time }));
						const msg = res.data.message;

						socket.emit("MESSAGE", {
							user: {
								name: auth.user.name,
								profile: auth.user.profile,
								_id: auth.user._id,
							},
							lastMessage: msg,
							...msg,
						});
					}
				} catch (error) {
					console.log(error.message);
				}
			};

			const formData = new FormData();
			formData.append("sender", auth.user._id);
			formData.append("recipient", userId);
			formData.append("media", msz.media);
			formData.append("time", msz.time);

			if (msz.media === "image") {
				dispatch(
					ADD_MESSAGE({
						message: {
							...msz,
							sender: auth.user._id,
							recipient: userId,
							isSent: false,
							message: URL.createObjectURL(msz.message),
						},
						userId: user._id,
					})
				);
				dispatch(
					SET_LAST_MESSAGE({
						lastMessage: {
							...msz,
							sender: auth.user._id,
							recipient: userId,
							message: URL.createObjectURL(msz.message),
						},
						userId: user._id,
					})
				);

				new Compressor(msz.message, {
					quality: 0.1,
					success: (compressedImage) => {
						formData.append("file", compressedImage);
						uploadFile(formData);
					},
					error: (err) => {
						dispatch(
							SET_NOTIFY({
								notifyType: {
									error: "something went wrong! please try again after a while",
								},
							})
						);
						return;
					},
				});
			} else if (msz.media === "video") {
				if (msz.message.size > 5400000) {
					dispatch(
						SET_NOTIFY({
							notifyType: { error: "video size is gretaer then 5mb" },
						})
					);
					return;
				}

				dispatch(
					ADD_MESSAGE({
						message: {
							...msz,
							sender: auth.user._id,
							recipient: userId,
							isSent: false,
							message: URL.createObjectURL(msz.message),
						},
						userId: user._id,
					})
				);
				dispatch(
					SET_LAST_MESSAGE({
						lastMessage: {
							...msz,
							sender: auth.user._id,
							recipient: userId,
							message: URL.createObjectURL(msz.message),
						},
						userId: user._id,
					})
				);

				formData.append("file", msz.message);
				uploadFile(formData);
			} else {
			}
		}
	};

	return (
		<div className="relative v-animation flex flex-col h-screen">
			<div className="shadow-md z-50">
				<MessageNav
					name={user?.name}
					profile={user?.profile}
					lastSeen={user?.lastSeen}
					_id={user?._id}
					switchScreen={switchScreen}
				/>
			</div>

			<div className="flex-1 overflow-y-scroll overflow-x-hidden p-2 md:p-4">
				{messages[userId]?.length > 0 &&
					messages[userId].map((message, key) => {
						return <Message key={key} message={message} />;
					})}
				<div ref={scrollRef} className="h-3"></div>
			</div>

			<div className="rounded-lg mb-16 md:mb-2">
				<MessageSender
					sendMessage={sendMessage}
					userId={userId}
					socket={socket}
				/>
			</div>
		</div>
	);
};

export default Messages;
