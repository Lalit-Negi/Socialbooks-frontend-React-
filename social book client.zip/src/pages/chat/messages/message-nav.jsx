import React, { useEffect, useRef } from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
	SET_USER_MESSAGE_COUNT_TO_ZERO,
	REMOVE_ALL_MESSAGES,
	SET_LAST_MESSAGE
} from "../../../store/reducers/conversation-reducer";
import { useDispatch, useSelector } from "react-redux";
import { deleteAllMessages } from "../../../http/api";
import { SET_NOTIFY } from "../../../store/reducers/notify-reducer";

const MesssageNav = ({ name, profile, lastSeen, _id, switchScreen }) => {
	const [model, toggleModel] = useState(false);
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const indexRef = useRef();
	const [deleteModel, setDeleteModel] = useState(false);
	const [status, setStatus] = useState(lastSeen);
	const users = useSelector((state) => state.conversation.users);
	indexRef.current = users.findIndex((user) => user._id === _id);

	useEffect(() => {
		setStatus(users[indexRef.current]?.lastSeen);
	}, [users[indexRef.current]?.lastSeen]);

	const handleDeleteMessages = async () => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await deleteAllMessages({ userId: _id });
			dispatch(SET_NOTIFY({ notifyType: { loading: false } }));
			if (res.status === 200) {
				setDeleteModel(false);
				dispatch(SET_NOTIFY({ notifyType: { message: res.data.message } }));
				dispatch(REMOVE_ALL_MESSAGES({ userId: _id }));
				dispatch(SET_LAST_MESSAGE({ userId : _id , lastMessage : ""}))
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { loading: false } }));
			console.log(error.message);
		}
	};

	return (
		<div
			className="flex justify-between items-center p-4 bg-transparent relative"
			onClick={() => toggleModel(false)}>
			<div className="flex space-x-2">
				<div
					className="w-8 h-8 md:w-12 md:h-12 overflow-hidden rounded-full"
					onClick={(e) => {
						e.stopPropagation();
						toggleModel((prev) => !prev);
					}}>
					<img
						src={profile}
						alt=""
						className="w-full h-full object-cover cursor-pointer"
					/>
				</div>
				<div className="flex-1">
					<p className="font-medium text-sm md:text-[18px] text-slate-800">
						{name}
					</p>
					<p className="text-xs text-slate-600 pt-[2px]">{status}</p>
				</div>
			</div>

			<div className="flex space-x-2 items-center">
				<button
					onClick={() => {
						dispatch(SET_USER_MESSAGE_COUNT_TO_ZERO({ userId: _id }));
						switchScreen(1);
					}}
					className="flex space-x-2 items-center bg-slate-200 hover:bg-slate-300 duration-300 transition-all py-2 px-2 md:px-4 rounded-full">
					<svg
						fill="gray"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="24"
						height="24">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M7.828 11H20v2H7.828l5.364 5.364-1.414 1.414L4 12l7.778-7.778 1.414 1.414z" />
					</svg>
					<p className="text-xs hidden md:block text-slate-800">Back</p>
				</button>

				<button
					className="bg-slate-200 hover:bg-slate-300 duration-300 transition-all p-2 rounded-full"
					onClick={() => setDeleteModel((prev) => !prev)}>
					<svg
						fill="gray"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="24"
						height="24">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M17 6h5v2h-2v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8H2V6h5V3a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v3zm1 2H6v12h12V8zM9 4v2h6V4H9z" />
					</svg>
				</button>
			</div>

			<div
				className={
					deleteModel
						? "delete-messages-model p-5 rounded-lg flex flex-col items-center glass"
						: "hidden"
				}>
				<h2 className="text-slate-600 mb-3 text-md">Delete all messages</h2>
				<div className="flex space-x-4">
					<button
						onClick={() => setDeleteModel(false)}
						className="bg-main text-sm text-white py-2 px-4 rounded-md hover:bg-hover transition-all duration-300">
						cancel
					</button>
					<button
						onClick={() => handleDeleteMessages()}
						className="bg-main text-sm text-white py-2 px-4 rounded-md hover:bg-hover transition-all duration-300">
						delete
					</button>
				</div>
			</div>

			<div
				className={
					model
						? "absolute top-20 left-4 right-4 rounded-md h-[70vh] overflow-hidden flex flex-col items-center glass w-full py-4"
						: "hidden"
				}>
				<div className="v-animation">
					<img
						src={profile}
						alt=""
						className="object-contain mb-3 rounded-sm h-full"
					/>
					<button
						onClick={() => navigate(`/profile/${_id}`)}
						className="bg-slate-200 hover:bg-slate-300 ml-8 duration-300 transition-all rounded-md py-[6px] px-3 text-sm text-slate-900">
						View Profile
					</button>
				</div>
			</div>
		</div>
	);
};

export default MesssageNav;
