import React from "react";
import moment from "moment";
import { useSelector } from "react-redux";
import { useState } from "react";

const MessageImage = ({ message }) => {
	const auth = useSelector((state) => state.auth);
	const [fullScreen , setFullScreen] = useState(false)
	return (
		<div
			className={`flex space-x-1 items-center ${
				message.sender === auth.user._id && "justify-end"
			}`}>
			{message.media === "image" && (
				<div
					className="relative"
					onClick={() => setFullScreen((prev) => !prev)}>
					<img
						src={message.message}
						alt=""
						className={`object-contain bg-black w-[content-fit] min-w-[160px] min-h-[120px] md:w-[content-fit] max-h-[280px] max-w-[240px]  md:max-w-[370px] rounded-md my-2 v-animation`}
					/>
					<p
						className={`md:text-[11px] text-[9px] lowercase text-slate-50 bg-black py-1 px-2 rounded-full absolute bottom-4 ${
							message.sender === auth.user._id ? "right-2" : "left-2"
						} `}>
						{moment(message.time).fromNow()}
					</p>
					<div
						className={
							fullScreen
								? "fixed top-0 right-0 bottom-0 left-0 z-[9999] bg-black"
								: "hidden"
						}>
						<img
							src={message.message}
							alt=""
							className="w-full h-full object-contain"
						/>{" "}
					</div>
				</div>
			)}
			{message.media === "video" && (
				<div className="relative">
					<video
						controls
						src={message.message}
						className={`object-contain bg-black min-w-[200px] w-[content-fit] min-h-[120px] md:w-[content-fit] max-h-[280px] max-w-[240px]  md:max-w-[370px]  v-animation rounded-md my-2 ${
							message.sender === auth.user._id ? "ml-auto" : ""
						}`}></video>
					<p
						className={`md:text-[11px] text-[9px] lowercase text-slate-50 bg-black py-1 px-3 rounded-full absolute bottom-4 ${
							message.sender === auth.user._id ? "right-2" : "left-2"
						} `}>
						{moment(message.time).fromNow()}
					</p>
				</div>
			)}
			{message.isSent === false && (
				<div>
					<svg
						className="fill-slate-500 animate-spin"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="18"
						height="18">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M18.537 19.567A9.961 9.961 0 0 1 12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10c0 2.136-.67 4.116-1.81 5.74L17 12h3a8 8 0 1 0-2.46 5.772l.997 1.795z" />
					</svg>
				</div>
			)}
		</div>
	);
};

export default MessageImage;
