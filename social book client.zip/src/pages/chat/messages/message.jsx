import React from "react";
import MessageImage from "./message-image";
import moment from "moment";
import { useSelector } from "react-redux";

const Message = ({ message }) => {
	const auth = useSelector(state => state.auth)

	return message.media === "text" ? (
		<div
			className={`flex items-center space-x-1 my-2 v-animation ${
				message.sender === auth.user._id ? "justify-end" : ""
			}`}>
			<div
				className={`text-[15px] py-2 px-3 rounded-lg ${
					message.sender === auth.user._id
						? "rounded-br-none"
						: "rounded-bl-none"
				} max-w-[80%] ${
					message.sender === auth.user._id ? "bg-green-300" : "bg-slate-200"
				}`}>
				<p>{message.message}</p>
				<p
					className={`md:text-[11px] text-[10px] inline text-slate-800 ${
						message.sender === auth.user._id ? "float-right" : "float-left"
					} lowercase`}>
					{moment(message.time).fromNow()}
				</p>
			</div>

			{message.isSent === false && (
				<div>
					<svg
						className="fill-slate-500 animate-spin"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="18"
						height="18">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M18.537 19.567A9.961 9.961 0 0 1 12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10c0 2.136-.67 4.116-1.81 5.74L17 12h3a8 8 0 1 0-2.46 5.772l.997 1.795z" />
					</svg>
				</div>
			)}
		</div>
	) : message.media === "image" || message.media === "video" ? (
		<MessageImage message={message} />
	) : (
		""
	);
};

export default Message;
