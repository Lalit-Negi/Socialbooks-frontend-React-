import React, { useState } from "react";
import { useSelector } from "react-redux";
import EmojiPicker from "emoji-picker-react";

const MessageSender = ({ sendMessage, userId, socket }) => {
	const [text, setText] = useState("");
	const [wait, setWait] = useState(true);
	const auth = useSelector((state) => state.auth);
	const [openEmoji, setOpenEmoji] = useState(false);

	const handleMessage = () => {
		setOpenEmoji(false);
		if (text.trim().length <= 0) return;
		const msz = {
			message: text.trim(),
			media: "text",
			time: Date.now(),
		};
		sendMessage(msz);
		setText("");
	};

	const handleImage = (e) => {
		const files = e.target.files;
		Array.from(files).forEach(async (file) => {
			const msz = {
				message: file,
				media: file.type.startsWith("image")
					? "image"
					: file.type.startsWith("video")
					? "video"
					: file.type,
				time: Date.now(),
			};
			sendMessage(msz);
		});
	};

	window.onkeypress = (e) => {
		e.key === "Enter" && handleMessage()
	};

	const handleText = (e) => {
		setText(e.target.value);

		if (wait) {
			socket.emit("TYPING", { myId: auth.user._id, userId });
			setWait(false);
			setTimeout(() => {
				setWait(true);
			}, 2000);
		}
	};

	return (
		<div className="flex items-center p-2 overflow-hidden space-x-2 md:space-x-4">
			<div className="p-2 rounded-full bg-slate-200">
				<label htmlFor="file">
					<svg
						className="fill-gray-700"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 24 24"
						width="22"
						height="22">
						<path fill="none" d="M0 0h24v24H0z" />
						<path d="M15 4H5v16h14V8h-4V4zM3 2.992C3 2.444 3.447 2 3.999 2H16l5 5v13.993A1 1 0 0 1 20.007 22H3.993A1 1 0 0 1 3 21.008V2.992zM13 12v4h-2v-4H8l4-4 4 4h-3z" />
					</svg>
				</label>
				<input
					type="file"
					id="file"
					multiple
					accept="image/*,video/*"
					className="hidden"
					onChange={handleImage}
				/>
			</div>

			<div className="p-2 rounded-full bg-slate-200 hidden xs:block">
				<div
					className={
						openEmoji
							? "absolute bottom-24 md:bottom-16 right-0 z-50 "
							: "hidden"
					}>
					<EmojiPicker
						onEmojiClick={(emojiObject) =>
							setText((prev) => prev + emojiObject.emoji)
						}
					/>
				</div>
				<svg
					onClick={() => setOpenEmoji((prev) => !prev)}
					className="fill-slate-700"
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="24"
					height="24">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm-4-7h8a4 4 0 1 1-8 0zm0-2a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm8 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" />
				</svg>
			</div>

			<div className="rounded-lg bg-slate-200 flex items-center px-2 md:px-4 space-x-2 md:space-x-4 flex-1">
				<input
					onChange={(e) => {
						handleText(e);
						setOpenEmoji(false);
					}}
					value={text}
					type="text"
					placeholder="Type a message"
					className="bg-transparent text-[13px] md:text-[15px] py-2 flex-1 focus:outline-none text-slate-800 h-11 placeholder:text-slate-700"
				/>

				<svg
					className="fill-gray-700"
					onClick={() => handleMessage()}
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="22"
					height="22">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M3.741 1.408l18.462 10.154a.5.5 0 0 1 0 .876L3.741 22.592A.5.5 0 0 1 3 22.154V1.846a.5.5 0 0 1 .741-.438zM5 13v6.617L18.85 12 5 4.383V11h5v2H5z" />
				</svg>
			</div>
		</div>
	);
};

export default MessageSender;
