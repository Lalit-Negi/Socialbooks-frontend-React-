import React, { useState } from "react";
import Sidebar from "../../components/sidebar";
import Contacts from "./contacts/contacts";
import Messages from "./messages/messages";
import { useDispatch } from "react-redux";
import { ADD_USER } from "../../store/reducers/conversation-reducer";

const Chat = () => {
	const [currentScreen, switchScreen] = useState(1);
	const dispatch = useDispatch();
	const [user, setUser] = useState();

	const handleUser = (user) => {
		setUser(user);
		dispatch(
			ADD_USER({
				user: {
					count: 0,
					...user,
					lastMessage: "",
					lastSeen: "",
					active: false,
				},
			})
		);
		switchScreen(2);
	};

	const screen = {
		1: <Contacts switchScreen={switchScreen} handleUser={handleUser} />,
		2: <Messages switchScreen={switchScreen} userId={user?._id} />,
	};

	return (
		<div className="flex">
			<Sidebar />
			<div className="shadow-xl flex-1 h-screen overflow-y-hidden max-w-screen-sm lg:ml-16">
				{screen[currentScreen]}
			</div>
		</div>
	);
};

export default Chat;
