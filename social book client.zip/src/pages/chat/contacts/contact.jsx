import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { SET_USER_MESSAGE_COUNT_TO_ZERO } from "../../../store/reducers/conversation-reducer";

const Contact = ({ user, handleUser }) => {
	const users = useSelector((state) => state.conversation.users);
	const indexRef = useRef();
	indexRef.current = users.findIndex((usr) => usr._id === user?._id);
	const [count, setCount] = useState(0);
	const [active, setActive] = useState(false);
	const dispatch = useDispatch();

	useEffect(() => {
		setCount(users[indexRef.current]?.count);
	}, [users[indexRef.current]?.count]);

	useEffect(() => {
		setActive(users[indexRef.current]?.active);
	}, [users[indexRef.current]?.active]);

	return (
		<div
			className="flex overflow-hidden space-x-2 md:space-x-4 bg-slate-50 transition-all px-2 py-4 md:p-4 ease-in duration-300 relative rounded-lg v-animation border border-slate-100 mb-2"
			onClick={() => {
				handleUser(user);
				dispatch(SET_USER_MESSAGE_COUNT_TO_ZERO({ userId: user?._id }));
			}}>
			<div className="md:w-11 md:h-11 w-10 h-10 overflow-hidden rounded-full">
				<img
					src={user?.profile}
					alt=""
					className="w-full h-full object-cover"
				/>
			</div>
			<div className="">
				<div className="flex space-x-2 items-center ">
					<p className="text-[15px] md:text-[16px]">{user?.name}</p>
					{active ? (
						<span className="w-[7px] h-[7px] bg-green-600 rounded-full"></span>
					) : (
						""
					)}
				</div>
				<p className="text-[12px] text-slate-500 pt-[2px] min-w[120px]">
					{user?.lastMessage?.media === "text" ? user?.lastMessage?.message.slice(0, 100) + " ..." : user?.lastMessage?.media === "image" ? "image": user?.lastMessage?.media === "video" ? "video" : user?.lastMessage?.message}
				</p>
			</div>
			<p className="text-[12px] text-slate-600 absolute top-0 right-0 pt-3 pr-3">
				{user?.lastSeen || ""}
			</p>
			{count === 0 ? (
				""
			) : (
				<p className="absolute top-8 right-4 align-baseline bg-red-600 w-5 h-5 text-xs text-white flex justify-center items-center rounded-full">
					{count}
				</p>
			)}
		</div>
	);
};

export default Contact;
