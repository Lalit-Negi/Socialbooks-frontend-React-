import React, { useEffect, useRef, useState } from "react";
import Contact from "./contact";
import { searchUser } from "../../../http/api";

const Search = ({ handleUser }) => {
	const [searchData, setSearchData] = useState([]);
	const searchRef = useRef();
	const [open, setOpen] = useState(searchData.length > 0 ? true : false);

	const findUser = async () => {
		if (searchRef.current.value.trim().length === 0) {
			return;
		}
		try {
			const res = await searchUser({ query: searchRef.current.value });
			if (res.status === 200) {
				setOpen(true);
				setSearchData(res.data.results);
			}
		} catch (error) {
			console.log(error.message);
			setOpen(false);
		}
	};

	useEffect(() => {
		const check = setInterval(() => {
			searchRef.current.value.length === 0 && setSearchData([]);
		}, 1000);

		return () => clearInterval(check);
	}, []);

	useEffect(() => {
		const check = setInterval(() => {
			if (searchData.length === 0) {
				setOpen(false);
			}
		}, 1000);
		return () => clearInterval(check);
	}, [searchData]);

	return (
		<div className="border border-slate-300 px-3 rounded-lg flex space-x-2 items-center relative">
			<svg
				fill="gray"
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 24 24"
				width="24"
				height="24">
				<path fill="none" d="M0 0h24v24H0z" />
				<path d="M12 14v2a6 6 0 0 0-6 6H4a8 8 0 0 1 8-8zm0-1c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6zm0-2c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm9.446 9.032l1.504 1.504-1.414 1.414-1.504-1.504a4 4 0 1 1 1.414-1.414zM18 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
			</svg>
			<input
				type="text"
				placeholder="search"
				ref={searchRef}
				onChange={findUser}
				className="border-l w-full border-slate-300 pl-3 py-2 focus:outline-none text-slate-500"
			/>

			{open && (
				<div className="glass bg-slate-100 overflow-y-scroll absolute left-0 right-0 top-[110%] z-50 py-4 px-4 rounded-lg v-animation shadow-2xl h-[70vh]">
					{searchData.length > 0 ? (
						searchData.map((user, key) => {
							return <Contact user={user} key={key} handleUser={handleUser} />;
						})
					) : (
						<p className="text-center text-lg text-slate-600">user not found</p>
					)}
				</div>
			)}
		</div>
	);
};

export default Search;
