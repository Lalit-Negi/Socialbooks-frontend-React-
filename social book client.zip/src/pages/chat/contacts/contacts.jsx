import React, { useEffect, useState } from "react";
import Search from "./search";
import Contact from "./contact";
import { useDispatch, useSelector } from "react-redux";
import { contacts } from "../../../http/api";
import { ADD_USER } from "../../../store/reducers/conversation-reducer";
import PostLoader from "../../../components/post-loader";

const Contacts = ({ handleUser }) => {
	const users = useSelector((state) => state.conversation.users);
	const dispatch = useDispatch();
	const [loading, setLoading] = useState(users.length > 0 ? false : true);

	const fetchContacts = async () => {
		try {
			const res = await contacts();
			if (res.status === 200) {
				setLoading(false)
				for (let contact of res.data.contacts) {
					dispatch(
						ADD_USER({
							user: {
								name: contact.recipient.name,
								profile: contact.recipient.profile,
								_id: contact.recipient._id,
								lastMessage: contact.lastMessage,
								lastSeen: contact.lastSeen || "",
								count: 0,
								active: false,
							},
						})
					);
				}
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	useEffect(() => {
		if (users.length <= 0) {
			fetchContacts();
		}
	});

	return (
		<div className="p-2 md:p-4 v-animation overflow-hidden">
			<Search handleUser={handleUser} />

			{loading && <PostLoader />}

			<div className="mt-4 overflow-y-scroll h-screen">
				{users.length > 0 ?
					users.map((user, key) => {
						return <Contact key={key} user={user} handleUser={handleUser} />;
					}) : <p className="text-sm text-center first-letter:capitalize text-slate-600">no previous chats. Search someone to chat</p>}
			</div>
		</div>
	);
};

export default Contacts;
