import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import Post from "../../components/home/posts/post";
import Sidebar from "../../components/sidebar";
import { getPost } from "../../http/api";
import {
	SET_POST,
	SET_LIKE,
	SET_DISLIKE,
	SET_COMMENT,
	SET_DELETE,
	SET_LOADING,
} from "../../store/reducers/post-reducer";
import PostLoader from "../../components/post-loader";
import { likePost, commentPost, deletePost, dislikePost } from "../../http/api";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";

const ShowPost = () => {
	const { postId } = useParams();
	const dispatch = useDispatch();
	const post = useSelector((state) => state.post);
	const socket = useSelector((state) => state.socketConnection.socket);
	const auth = useSelector((state) => state.auth);

	useEffect(() => {
		(async () => {
			try {
				const res = await getPost({ postId });
				if (res.status === 200) {
					dispatch(SET_POST({ post: res.data.post }));
					dispatch(SET_LOADING({ loading: false }));
				}
			} catch (error) {
				console.log(error.message);
				dispatch(SET_LOADING({ loading: false }));
			}
		})();
	}, []);

	const handleLike = async (postId) => {
		const user = {
			name: auth.user.name,
			profile: auth.user.profile,
			_id: auth.user._id,
		};

		dispatch(SET_LIKE({ user }));

		try {
			const res = await likePost({ postId });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));

				socket.emit("LIKE_POST", {
					postId,
					friends: auth.user.followers,
					user,
				});
			}
		} catch (error) {
			console.log(error);
		}
	};

	const handleDislike = async (postId) => {
		dispatch(
			SET_DISLIKE({
				userId: auth.user._id,
			})
		);

		try {
			const res = await dislikePost({ postId });
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				socket.emit("UNLIKE_POST", {
					postId,
					friends: auth.user.followers,
					userId: auth.user._id,
				});
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleComment = async (postId, comment, setComment) => {
		if (!comment) {
			return;
		}
		const user = {
			userComment: {
				name: auth.user.name,
				profile: auth.user.profile,
				_id: auth.user._id,
			},
			text: comment,
			createdAt: Date.now(),
		};

		try {
			const res = await commentPost({ postId, comment });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				dispatch(SET_COMMENT({ user }));
				socket.emit("COMMENT_POST", {
					postId,
					user,
					friends: auth.user.followers,
				});
			}
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}

		try {
			setComment((prev) => "");
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleDeletePost = async (postId, setRemovePost) => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await deletePost(postId);
			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 200) {
				dispatch(SET_DELETE());
			}
			dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			setRemovePost(false);

			socket.emit("DELETE_POST", {
				friends: auth.user.followers,
				postId,
			});
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	return (
		<div className="flex max-w-screen-sm">
			<Sidebar />

			<div className="overflow-y-scroll py-4 h-screen px-4">
				{post.post ? (
					<Post
						post={post.post}
						handleLike={handleLike}
						handleDislike={handleDislike}
						handleComment={handleComment}
						handleDeletePost={handleDeletePost}
					/>
				) : post.loading ? (
					<PostLoader />
				) : (
					<p className="mt-4 text-xs sm:text-lg text-slate-600 text-center">No Post</p>
				)}
			</div>
		</div>
	);
};

export default ShowPost;
