import { useEffect, useRef, useState } from "react";
import { createPost, createNotification } from "../../http/api";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import { useDispatch, useSelector } from "react-redux";
import { ADD_POST } from "../../store/reducers/homePost-reducer";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper";
import "swiper/css/pagination";
import "swiper/css";
import Compressor from "compressorjs";

const PostModel = ({ openPost, setOpenPost }) => {
	const socket = useSelector((state) => state.socketConnection.socket);
	const caption = useRef();
	const [images, setImages] = useState([]);
	const dispatch = useDispatch();
	const user = useSelector((state) => state.auth.user);

	const handleImages = (e) => {
		if (!e.target.files) {
			return;
		}
		setImages((prev) => [...prev, ...e.target.files]);
	};

	const handleSubmit = async () => {
		if (caption.current.value.length <= 0 && images.length <= 0) {
			dispatch(SET_NOTIFY({ notifyType: { error: "no data has to upload!" } }));
			return;
		}
		const formData = new FormData();
		formData.append("caption", caption.current.value);

		dispatch(SET_NOTIFY({ notifyType: { loading: true } }));

		images.forEach((image, index) => {
			new Compressor(image, {
				quality: 0.1,
				success: (compressedImage) => {
					formData.append("images", compressedImage);
					if (index === images.length - 1 ) {
						uploadPost();
					}
				},
				error: (err) => {
					dispatch(
						SET_NOTIFY({
							notifyType: {
								error: "something went wrong! please try again after a while",
							},
						})
					);
					return;
				},
			});
		});

		async function uploadPost() {
			try {
				const res = await createPost(formData);
				dispatch(SET_NOTIFY({ notifyType: {} }));
				if (res.status === 201) {
					setOpenPost((prev) => !prev);
					dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
					setImages([]);
					caption.current.value = "";
					const newPost = {
						...res.data.newPost,
						user: { name: user.name, profile: user.profile, _id: user._id },
					};

					dispatch(ADD_POST({ post: newPost }));
					socket.emit("ADD_POST", { post: newPost, friends: user.followers });

					try {
						const data = {
							link: `/post/${newPost._id}`,
							text: `${user.name} added a new post`,
							recipient: user.followers,
							profile: user.profile,
						};
						const res = await createNotification(data);

						if (res.status === 201) {
							socket.emit("NOTIFICATION", res.data.notification);
						}
					} catch (error) {
						dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
					}
				}
			} catch (error) {
				dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
			}
		}
	};

	return (
		<div className={openPost ? "status-model z-50 v-animation" : "hidden"}>
			<div
				className="absolute right-4 top-[12px] bg-white rounded-full"
				onClick={() => setOpenPost((prev) => !prev)}>
				<svg
					fill="gray"
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 24 24"
					width="35"
					height="35">
					<path fill="none" d="M0 0h24v24H0z" />
					<path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
				</svg>
			</div>

			<div className="max-w-[460px] w-[96%] rounded-sm overflow-hidden">
				<div className="flex overflow-x-auto space-x-2 items-center bg-black h-[260px] mx-auto">
					<Swiper
						spaceBetween={0}
						slidesPerView={1}
						modules={[Pagination]}
						pagination={{
							dynamicBullets: true,
						}}
						className="swiper pb-4">
						{images.map((image, key) => {
							return (
								<SwiperSlide key={key}>
									<div className="overflow-hidden mb-4 rounded-sm bg-black h-[300px] flex justify-center">
										<img
											key={key}
											src={image ? URL.createObjectURL(image) : null}
											alt="not found"
											className="h-full w-full object-contain"
										/>
									</div>
								</SwiperSlide>
							);
						})}
					</Swiper>
				</div>

				<div className="my-4 flex justify-between items-center space-x-4">
					<div className="mr-4 border-b border-slate-200 my-4 flex-1 px-4">
						<textarea
							type="text"
							placeholder="write something here ..."
							rows="1"
							className="focus:outline-none text-[14px] sm:text-[15px] py-1 bg-transparent text-white w-full tracking-wide caret-white"
							ref={caption}
						/>
					</div>

					<div>
						<label htmlFor="post">
							<svg
								fill="white"
								xmlns="http://www.w3.org/2000/svg"
								viewBox="0 0 24 24"
								width="30"
								height="30">
								<path fill="none" d="M0 0h24v24H0z" />
								<path d="M21 15v3h3v2h-3v3h-2v-3h-3v-2h3v-3h2zm.008-12c.548 0 .992.445.992.993v9.349A5.99 5.99 0 0 0 20 13V5H4l.001 14 9.292-9.293a.999.999 0 0 1 1.32-.084l.093.085 3.546 3.55a6.003 6.003 0 0 0-3.91 7.743L2.992 21A.993.993 0 0 1 2 20.007V3.993A1 1 0 0 1 2.992 3h18.016zM8 7a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" />
							</svg>
						</label>
						<input
							id="post"
							type="file"
							multiple
							accept="image/*"
							className="hidden"
							onChange={handleImages}
						/>
					</div>
				</div>

				<div className="flex justify-end">
					<button
						className="bg-main rounded-md py-1 md:py-2 px-3 md:px-8 text-white capitalize hover:bg-hover transition-all duration-300"
						onClick={handleSubmit}>
						post
					</button>
				</div>
			</div>
		</div>
	);
};

export default PostModel;
