import React, { useEffect, useState } from "react";
import Feed from "../../components/home/feed";
import Sidebar from "../../components/sidebar";
import { feed } from "../../http/api";
import Post from "../../components/home/posts/post";
import { useSelector, useDispatch } from "react-redux";
import { SET_NOTIFY } from "../../store/reducers/notify-reducer";
import InfiniteScroll from "react-infinite-scroll-component";
import PostLoader from "../../components/post-loader";
import {
	SET_POSTS,
	SET_COMMENT,
	SET_LIKE,
	SET_DELETE,
	SET_DISLIKE,
	SET_LOADING,
} from "../../store/reducers/homePost-reducer";
import { likePost, commentPost, deletePost, dislikePost } from "../../http/api";

const Home = () => {
	const auth = useSelector((state) => state.auth);
	const dispatch = useDispatch();
	const homePosts = useSelector((state) => state.homePosts);
	const [isMore, setIsMore] = useState(true);
	const socket = useSelector((state) => state.socketConnection.socket);

	const handleLike = async (postId) => {
		const user = {
			name: auth.user.name,
			profile: auth.user.profile,
			_id: auth.user._id,
		};

		dispatch(SET_LIKE({ postId, user }));

		try {
			const res = await likePost({ postId });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));

				socket.emit("LIKE_POST", {
					postId,
					friends: auth.user.followers,
					user,
				});
			}
		} catch (error) {
			console.log(error);
		}
	};

	const handleDislike = async (postId) => {
		dispatch(
			SET_DISLIKE({
				postId,
				userId: auth.user._id,
			})
		);

		try {
			const res = await dislikePost({ postId });
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				socket.emit("UNLIKE_POST", {
					postId,
					friends: auth.user.followers,
					userId: auth.user._id,
				});
			}
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleComment = async (postId, comment, setComment) => {
		if (!comment) {
			return;
		}
		const user = {
			userComment: {
				name: auth.user.name,
				profile: auth.user.profile,
				_id: auth.user._id,
			},
			text: comment,
			createdAt: Date.now(),
		};

		try {
			const res = await commentPost({ postId, comment });
			if (res.status === 201) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
				dispatch(SET_COMMENT({ postId, user, socket }));
				socket.emit("COMMENT_POST", {
					postId,
					user,
					friends: auth.user.followers,
				});
			}
			if (res.status === 200) {
				dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			}
		} catch (error) {
			console.log(error);
		}

		try {
			setComment((prev) => "");
		} catch (error) {
			console.log(error.message);
		}
	};

	const handleDeletePost = async (postId, setRemovePost) => {
		try {
			dispatch(SET_NOTIFY({ notifyType: { loading: true } }));
			const res = await deletePost(postId);
			dispatch(SET_NOTIFY({ notifyType: {} }));
			if (res.status === 200) {
				dispatch(SET_DELETE({ postId, socket }));
			}
			dispatch(SET_NOTIFY({ notifyType: { success: res.data.message } }));
			setRemovePost(false);

			socket.emit("DELETE_POST", {
				friends: auth.user.followers,
				postId,
			});
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	const fetchFeed = async () => {
		try {
			dispatch(SET_LOADING({ loading: true }));
			const res = await feed({
				limit: homePosts.limit,
				skip: homePosts.skip,
			});
			if (res.status === 200) {
				if (res.data.feed.length === 0) {
					setIsMore(false);
					dispatch(SET_LOADING({ loading: false }));
				} else {
					dispatch(
						SET_POSTS({
							posts: [...homePosts.posts, ...res.data.feed],
						})
					);
					dispatch(SET_LOADING({ loading: false }));
				}
			}
		} catch (error) {
			dispatch(SET_NOTIFY({ notifyType: { error: error.message } }));
		}
	};

	useEffect(() => {
		if (homePosts.posts.length === 0) {
			fetchFeed();
		}
	}, []);

	return (
		<div className="flex">
			<Sidebar />

			<div
				className="shadow-xl flex-1 p-2 md:p-4 h-screen overflow-y-scroll v-animation max-w-screen-sm lg:ml-16"
				id="scrollableDiv">
				<Feed />

				<InfiniteScroll
					dataLength={homePosts.posts.length}
					next={fetchFeed}
					hasMore={isMore}
					scrollableTarget="scrollableDiv"
					>
					{homePosts.posts.length > 0 ? (
						homePosts.posts.map((post, key) => {
							return (
								<Post
									post={post}
									key={key}
									handleLike={handleLike}
									handleDislike={handleDislike}
									handleComment={handleComment}
									handleDeletePost={handleDeletePost}
								/>
							);
						})
					) : (
						<div className="flex items-center flex-col">
							<h2 className="my-4 text-xl text-slate-500">No posts</h2>							
						</div>
					)}
				</InfiniteScroll>

				{homePosts.loading && <PostLoader />}
			</div>
		</div>
	);
};

export default Home;
